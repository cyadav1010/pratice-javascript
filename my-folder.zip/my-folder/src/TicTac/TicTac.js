import React, { useState } from "react";
import "./style.css";
const TicTac = () => {
    let grid = [
        [-1, -1, -1],
        [-1, -1, -1],
        [-1, -1, -1],
    ];
    const [gridBox, setGridBox] = useState(grid);
    const [playerTurn, setPlayerTurn] = useState(0);
    const [winner, setWinner] = useState(null);
    const handleClick = (row, col) => {
        console.log("row, col", row, col);
        let tempGrid = JSON.parse(JSON.stringify(gridBox));
        if (playerTurn == 0) {
            tempGrid[row][col] = 0;
            setPlayerTurn("x");
        } else {
            tempGrid[row][col] = "x";
            setPlayerTurn(0);
        }
        setGridBox(tempGrid);
        const winner = checkWinner(tempGrid);
        console.log("winner", winner);
        setWinner(winner);
    };
    const checkWinner = (gridBox) => {
        for (let row = 0; row < gridBox.length; row++) {
            if (
                gridBox[row][0] != -1 &&
                gridBox[row][0] == gridBox[row][1] &&
                gridBox[row][1] == gridBox[row][2]
            ) {
                return gridBox[row][0];
            }
        }
        for (let col = 0; col < gridBox[0].length; col++) {
            if (
                gridBox[0][col] != -1 &&
                gridBox[0][col] == gridBox[1][col] &&
                gridBox[1][col] == gridBox[2][col]
            ) {
                return gridBox[0][col];
            }
        }
        if (
            gridBox[0][0] != -1 &&
            gridBox[0][0] == gridBox[1][1] &&
            gridBox[1][1] == gridBox[2][2]
        ) {
            return gridBox[0][0];
        }
        if (
            gridBox[2][0] != -1 &&
            gridBox[2][0] == gridBox[1][1] &&
            gridBox[1][1] == gridBox[0][2]
        ) {
            return gridBox[2][0];
        }
        return "";
    };
    return (
        <div>
            <>
                {gridBox.map((ele, row) => {
                    return (
                        <div className="ticTac">
                            {ele?.map((item, col) => {
                                return (
                                    <div className="ticBox" onClick={() => handleClick(row, col)}>
                                        {item != -1 ? item : ""}
                                    </div>
                                );
                            })}
                        </div>
                    );
                })}
            </>
            <div>{winner}</div>
        </div>
    );
};

export default TicTac;
