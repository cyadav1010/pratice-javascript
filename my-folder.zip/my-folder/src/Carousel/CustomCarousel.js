import React, { useState, useEffect } from 'react'
import { useRef } from 'react';

const CustomCarousel = ({ slides }) => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const intervalRef = useRef();
  const slidesRef = useRef([]);
  const handlePrevSlide = () => {
    stopAutoPlay();
    setCurrentIndex((prevIndex) => {
      if (prevIndex == 0) {
        return slides.length - 1;
      } else {
        return prevIndex - 1;
      }
    })
    startAutoPlay();
  }
  const handleNextSlide = () => {
    stopAutoPlay();
    setCurrentIndex((prevIndex) => (prevIndex + 1) % slides.length);
    startAutoPlay();
  }
  const startAutoPlay = () => {
    if (!intervalRef.current) {
      intervalRef.current = setInterval(handleNextSlide, 1000);
    }
  };
  // Stop auto-play
  const stopAutoPlay = () => {
    if (intervalRef.current) {
      clearInterval(intervalRef.current);
    }
  };
  useEffect(() => {
    startAutoPlay();
    return () => {
      stopAutoPlay();
    }
  }, [])

  useEffect(() => {
    const observer = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          const img = entry.target;
          img.src = img.dataset.src;
        }
      })
    })

    slidesRef.current.forEach((img) => {
      if (img && img.dataset.src) {
        observer.observe(img);
      }
    })
    return () => {
      observer.disconnect();
    }
  }, [])
  return (
    <div>
      <div className='carouselWrapper'>
        {slides?.map((slide, index) => {
          return (
            <>
              {
                // index === currentIndex ?
                <div key={index}
                  // ref={(el)=>slidesRef.current[index]=el}
                  className={`slide ${index === currentIndex ? "active" : ""}`}
                  style={{ transform: `translateX(${(index - currentIndex) * 100}%)` }}
                >
                  <img
                    ref={(el) => (slidesRef.current[index] = el)}
                    data-src={slide.imageUrl}
                    loading="lazy"
                  />
                  {/* { slide.} */}
                  <p>{slide.content}</p>
                </div>
                // : ""
              }
            </>
          )
        })}

      </div>
      <button onClick={handlePrevSlide} aria-label="Next Slide">
        prev
      </button>
      <button onClick={handleNextSlide}>
        next
      </button>
    </div>
  )
}

export default CustomCarousel