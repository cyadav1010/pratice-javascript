import React from 'react';
import CircularCarousel from './CircularCarousel';
import CustomCarousel from './CustomCarousel';
import './style.css';
// import { priorityExample } from '../Programming/Practice.js'
const {
  PriorityQueue,
  MinPriorityQueue,
  MaxPriorityQueue,
} = require('@datastructures-js/priority-queue');
const MyCarousel = () => {
    
     function priorityExample() {
  
const arr = [10, 22, 4, 5, 21, 8, 9, 59];
const numbersMinQueue = new MinPriorityQueue();
const numbersMaxQueue = new MaxPriorityQueue();

for (const num of arr) {
  numbersMinQueue.enqueue(num);
  numbersMaxQueue.enqueue(num);
}

         console.log(numbersMinQueue.toArray());
         console.log(numbersMaxQueue.toArray());
     }
    priorityExample();
    const slides = [
        {
            imageUrl: "https://picsum.photos/id/1/200/300",
            alt: "Slide 2 Desc",
            content: "Slide 1 Content"
        },
        {
            imageUrl: "https://picsum.photos/id/2/200/300",
            alt: "Slide 2 Desc",
            content: "Slide 2 Content"
        },
        {
            imageUrl: "https://picsum.photos/id/3/200/300",
            alt: "Slide 2 Desc",
            content: "Slide 3 Content"
        },
        {
            imageUrl: "https://picsum.photos/id/4/200/300",
            alt: "Slide 2 Desc",
            content: "Slide 4 Content"
        },
        {
            imageUrl: "https://picsum.photos/id/5/200/300",
            alt: "Slide 2 Desc",
            content: "Slide 5 Content"
        },
        // https://picsum.photos/id/1/200/300
    ]
    return (
        <div>
            {/* <CustomCarousel slides={slides} /> */}
            <CircularCarousel slides={slides} />
        </div>
    )
}

export default MyCarousel