import React, { useState, useEffect, useRef } from "react";

const CircularCarousel = ({ slides }) => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const slidesRef = useRef(null);

  // Duplicate the slides array to create a seamless loop
  const duplicatedSlides = [...slides, ...slides, ...slides];

  useEffect(() => {
    const slidesContainer = slidesRef.current;

    // Scroll to the middle section initially
    const initialScrollPosition = slides.length * window.innerWidth;
    slidesContainer.scrollLeft = initialScrollPosition;

    // Handle scroll events
    const handleScroll = () => {
      const scrollLeft = slidesContainer.scrollLeft;
      const totalWidth = slidesContainer.scrollWidth;
      const viewportWidth = slidesContainer.clientWidth;

      // Check if the user has scrolled to the beginning or end
      if (scrollLeft <= 0) {
        // User scrolled to the beginning, jump to the equivalent position in the middle
        slidesContainer.scrollLeft += slides.length * viewportWidth;
      } else if (scrollLeft >= totalWidth - viewportWidth) {
        // User scrolled to the end, jump to the equivalent position in the middle
        slidesContainer.scrollLeft -= slides.length * viewportWidth;
      }
    };

    slidesContainer.addEventListener("scroll", handleScroll);

    return () => {
      slidesContainer.removeEventListener("scroll", handleScroll);
    };
  }, [slides]);

  return (
    <div className="carouselWrapper">
      <div className="slides" ref={slidesRef}>
        {duplicatedSlides.map((slide, index) => (
          <div key={index} className="slide">
            <img src={slide.imageUrl} alt={slide.alt || "Carousel Slide"} />
            <p>{slide.content}</p>
          </div>
        ))}
      </div>
    </div>
  );
};

export default CircularCarousel;