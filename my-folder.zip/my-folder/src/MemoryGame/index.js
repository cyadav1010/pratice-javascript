import React from 'react'
import Game from './Game'

const MemoryGame = () => {
    let totals = 12;
  return (
    <div><Game total={totals}/></div>
  )
}

export default MemoryGame