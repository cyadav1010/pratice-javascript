import React,{useState, useEffect} from 'react'
import './style.css';
//  on click one number show the option value
// if two selected option is correct then show same color green 
// if two selected is wrong then de select and again hide the number 

const Game = ({total}) => {
    console.log("total",total);
    const arrayBoxes= new Array(12).fill(0);
    const [correctBoxes, setCorrectBoxes] = useState([]);
    const [boxesData, setBoxesData] = useState([]);
    const [selectedOption, setSelectedOption] = useState([]);
    const getRandomNumber=(number)=>{
        let num =Math.floor(Math.random()*number);
        return num;
    }
    const checkNumIsPresentTwice=(data,num)=>{
        let count = 0;
         data?.forEach(element => {
            if(element==num){
                count++; 
            }
         });
         if(count ==2){
            return true;
         }
         return false;
    };
    const isValidNumber=(data)=>{
        let rnd = getRandomNumber(data?.length);

    };
    const assignRandomNumber=()=>{
        console.log("boxesData",boxesData);
        while(boxesData?.length!=arrayBoxes?.length){
            let rnd = getRandomNumber(arrayBoxes?.length/2);
            console.log("random data",rnd);
            if(!checkNumIsPresentTwice(boxesData,rnd)){
               let tempboxesData = [...boxesData];
               tempboxesData.push(rnd);
               setBoxesData(tempboxesData);
            }
        }
    }
    const assignData=()=>{
        let tempAr=[];
        console.log("arrayBoxes",arrayBoxes);
        arrayBoxes?.forEach((ele,index)=>{
            // console.log("index",index);
            let value = Math.floor(index/2);
            tempAr.push(value);
        })
        shuffleData(tempAr);
    };
    const shuffleData=(data)=>{
        let tempData = [...data];
        for (let index = 0; index < data.length; index++) {
            // tempData[]
           let rnd = getRandomNumber(data?.length/2);
        //    console.log("rnd===>",rnd);
           let temp = tempData[rnd];
           let temp1 = tempData[index];
           tempData[index] = temp;
           tempData[rnd] = temp1;
        }
        console.log("tempData",tempData);
        setBoxesData(tempData);
    }
    useEffect(() => {
        // assignRandomNumber();
        assignData();
    }, [])

    const handleClickBox =(value)=>{
        console.log("indvalueex",value);
        if(selectedOption.length==2){
            // check both are equal or not 
            // if() 
            const[index1,index2]=selectedOption;
            if(boxesData[index1]==boxesData[index2]){
                // correctBoxes, setCorrectBoxes
                let correctAns= [...correctBoxes];
                correctAns.push(index1);
                correctAns.push(index2);
                setCorrectBoxes(correctAns);
            }
            setSelectedOption([]);
        }else{
            let option =[...selectedOption];
            option.push(value);
            setSelectedOption(option);
        }
    };

    useEffect(() => {
        console.log("boxesData",boxesData);
    }, [boxesData]);
  return (
    <div> 
        <div className='game-container'>
        {boxesData?.map((box,index)=>{
            let isSelected = selectedOption?.find((ele)=>ele ==index);
            let isCorrectOption =correctBoxes?.find((ele)=>ele==index);
        return (
        <div 
        className={` item-box , ${isSelected ? 'selectedItems' :''} ${isCorrectOption ? 'correctAnswer' : ''}`} 
        onClick={()=>handleClickBox(index)}>
        { (isSelected || isCorrectOption)  && <span> {box}</span>}
        </div>)
         })}
        </div>
        </div>
  )
}

export default Game;