import React from 'react'
import ImageSlider from './ImageSlider';

const ImageSliderApp = () => {
    const inputImages = [
        'https://picsum.photos/id/1/300/200',
        'https://picsum.photos/id/2/300/200',
        'https://picsum.photos/id/3/300/200',
        'https://picsum.photos/id/4/300/200',
      ];
    
  return (
    <div><ImageSlider inputImages={inputImages}/></div>
  )
}

export default ImageSliderApp