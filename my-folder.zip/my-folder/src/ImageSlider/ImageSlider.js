// import React,{useState,useEffect} from 'react'
// import './style.css';

// const ImageSlider = ({inputImages}) => {
//     console.log("inputImages",inputImages);
//     const [images, setImages] = useState(inputImages);
//     const [currentIndex, setCurrentIndex] = useState(0);
//     const handleClickBox =(index)=>{
//         setCurrentIndex(index);
//     };

//     useEffect(() => {
//         const interval = setInterval(() => {
//            let tempCurrentIndex = currentIndex + 1;
//            console.log("tempCurrentIndex",tempCurrentIndex);
//             if(tempCurrentIndex > images.length){
//                 tempCurrentIndex = 0;
//             }
//             setCurrentIndex(tempCurrentIndex);
//         }, 1000);
//         return ()=>{
//             clearInterval(interval);
//         }
//     }, [currentIndex]);

//   return (
//     <div className=''>
//         {images?.map((image,index)=>(
//     <div className='imageSlider'>
//         {index ==currentIndex && <img src={image}/>}
//         </div>
//     ))}
//     <div className='imageBoxWrapper'>
//     {images?.map((ele,index)=>(<div className= {`imageBox ${index==currentIndex ? 'selectedBox' :'' }`} onClick={()=>handleClickBox(index)}></div>))}
//     </div>
//     </div>
//   )
// }

// export default ImageSlider


import React, { useState, useEffect } from 'react';
// import './ImageSlider.css';
import './style.css';

const ImageSlider = ({ inputImages, interval = 5000 }) => {
  const [currentImageIndex, setCurrentImageIndex] = useState(0);

  // Auto-slide functionality
  useEffect(() => {
    const slideInterval = setInterval(() => {
      handleNextImageClick();
    }, interval);

    return () => clearInterval(slideInterval);
  }, [currentImageIndex]);

  const handleNextImageClick = () => {
    setCurrentImageIndex(
      (prevImageIndex) => (prevImageIndex + 1) % inputImages.length
    );
  };

  const handlePrevImageClick = () => {
    setCurrentImageIndex((prevImageIndex) =>
      prevImageIndex === 0 ? inputImages.length - 1 : prevImageIndex - 1
    );
  };

  return (
    <div className="slider">
      <div className="slider-content">
        <img
          src={inputImages[currentImageIndex]}
          alt="slider"
          className="slider-image"
        />
        <button className="prev" onClick={handlePrevImageClick}>
          &#10094;
        </button>
        <button className="next" onClick={handleNextImageClick}>
          &#10095;
        </button>
      </div>
    </div>
  );
};

export default ImageSlider;