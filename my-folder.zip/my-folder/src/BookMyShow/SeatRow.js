import React from 'react'
import Seat from './Seat'

const SeatRow = ({row,seats,onSelect}) => {
  return (
      <div className='seat-row'>
          <span>{row}</span>
          {seats?.map((seat,index) => {
              return (<Seat key={seat.id} seat={seat} onSelect={onSelect} />)
          })}
    </div>
  )
}

export default SeatRow