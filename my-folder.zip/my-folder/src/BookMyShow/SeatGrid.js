import React from 'react'
import SeatRow from './SeatRow';

const SeatGrid = ({ seats, onSelect }) => {
    const groupedSeats = {};
     // Iterate over each seat and group them by category and then by row
  seats.forEach((seat) => {
    if (!groupedSeats[seat.category]) {
      groupedSeats[seat.category] = {};
    }

    if (!groupedSeats[seat.category][seat.row]) {
      groupedSeats[seat.category][seat.row] = [];
    }

    groupedSeats[seat.category][seat.row].push(seat);
  });
    Object.keys(groupedSeats).forEach((category) => {
        Object.keys(groupedSeats[category]).forEach((row) => {
            groupedSeats[category][row].sort((a, b) => Number(a.label) - Number(b.label));
      }) 
    })
  return (
      <div>
          {Object.keys(groupedSeats).map((category) => {
              let price = seats.find((s) => s.category == category)?.price;
              return (
                  <div>
                      <h3> {category} - {price }</h3>
                      {Object.keys(groupedSeats[category])?.map((row) => {
                          return (<SeatRow seats={groupedSeats[category][row]} row={row} onSelect={onSelect}/>)
                      })}
                  </div>
              )
          })}
    </div>
  )
}

export default SeatGrid