import React from 'react'

const Seat = ({ seat, onSelect }) => {
    console.log("seat==>>", seat);
    const handleClick = () => {
        console.log("click seat", seat);
        if (seat.status == "available") {
            onSelect(seat.id);
        }
    }
    return (
        <>
            <div
                className={`seat ${seat.status}`}
                onClick={handleClick}
            >
                {seat.status!="hide"&&seat.label}
            </div>
        </>
    )
}

export default Seat