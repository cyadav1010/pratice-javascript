const seatsData = [
    {
        id: "A2",
        label: "2",
        row: "A",
        column: 2,
        category: "Gold Prime",
        price: 230,
        status:"available"
    },
    {
        id: "A1",
        label: "1",
        row: "A",
        column: 1,
        category: "Gold Prime",
        price: 230,
        status:"booked"
    },
    {
        id: "A3",
        label: "3",
        row: "A",
        column: 3,
        category: "Gold Prime",
        price: 230,
        status:"available"
    },
    {
        id: "B1",
        label: "1",
        row: "B",
        column: 1,
        category: "Gold Prime",
        price: 230,
        status:"available"
    },
    {
        id: "B2",
        label: "2",
        row: "B",
        column: 2,
        category: "Gold Prime",
        price: 230,
        status:"available"
    },
    {
        id: "B3",
        label: "3",
        row: "B",
        column: 3,
        category: "Gold Prime",
        price: 230,
        status:"available"
    },
    {
        id: "A1",
        label: "1",
        row: "A",
        column: 1,
        category: "silver Prime",
        price: 230,
        status:"available"
    },
    {
        id: "A2",
        label: "2",
        row: "A",
        column: 2,
        category: "silver Prime",
        price: 230,
        status:"available"
    },
    {
        id: "A3",
        label: "3",
        row: "A",
        column: 3,
        category: "silver Prime",
        price: 230,
        status:"hide"
    },
    {
        id: "A4",
        label: "4",
        row: "A",
        column: 4,
        category: "silver Prime",
        price: 230,
        status: "available",
        
    },
    {
        id: "B1",
        label: "1",
        row: "B",
        column: 1,
        category: "silver Prime",
        price: 230,
        status:"available"
    },
    {
        id: "B2",
        label: "2",
        row: "B",
        column: 2,
        category: "silver Prime",
        price: 230,
        status:"available"
    },
    {
        id: "B3",
        label: "3",
        row: "B",
        column: 3,
        category: "silver Prime",
        price: 230,
        status:"available"
    },
]

export default seatsData;

// status -> available , selected, hide, booked,