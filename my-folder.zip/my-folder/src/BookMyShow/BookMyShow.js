import React,{useState,useEffect} from 'react';
import seatsData from './data';
import SeatGrid from './SeatGrid';
import './style.css';
const BookMyShow = () => {
  const [seats, setSeats] = useState(seatsData);
  const [selectedSeat, setSelectedSeat] = useState([]);
  const [totalPrice, setTotalPrice] = useState(0);
  // first group based on category 
  // after each group sort based on row

  const seatGrouping = () => {
    const groupedSeats = {};
  // Iterate over each seat and group them by category and then by row
  seats.forEach((seat) => {
    if (!groupedSeats[seat.category]) {
      groupedSeats[seat.category] = {};
    }

    if (!groupedSeats[seat.category][seat.row]) {
      groupedSeats[seat.category][seat.row] = [];
    }

    groupedSeats[seat.category][seat.row].push(seat);
  });
    console.log("groupedSeats", groupedSeats);

    // let seatMap = new Map();
    // for (let i = 0; i < seats.length; i++) {
    //   let key = seats[i].category;
    //   if (!seatMap.has(seats[i].category)) {
    //     seatMap.set(key, []);
    //   }
      
    //   let tempSeat = seatMap.get(key);
    //   // if(!)
    //   tempSeat.push(seats[i]);
    // }
    // console.log("seatMap", seatMap);
  };

  const catergoryGrouping = () => {
    let groupedSeats = new Map();
    seats.forEach((seat) => {
      let keyCat = seat.category;
      if (!groupedSeats.has(keyCat)) {
        groupedSeats.set(keyCat, new Map());
      }
      const categoryMap = groupedSeats.get(keyCat);
      if (!categoryMap.has(seat.row)) {
        categoryMap.set(seat.row, []);
      }
      categoryMap.get(seat.row).push(seat);
    })
    console.log("groupedSeats", groupedSeats);
  }
  useEffect(() => {
    seatGrouping();
    catergoryGrouping();
  }, [])
  const onSelect = (seatId) => {
    console.log("seatId", seatId);
    
  }
  return (
    <div>
      <SeatGrid seats={seats} onSelect={ onSelect} />
    </div>
  )
}

export default BookMyShow