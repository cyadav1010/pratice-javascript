import React, { memo,useState } from 'react';
import AddComments from './AddComments';

const Comments = memo(({
    commentsList = [],
    addCommentsReply = () => {},
    activeReplyBox,
    setActiveReplyBox,
}) => {
    const [visibleReplies, setVisibleReplies] = useState({});

    const handleVisibleReplies = (commentId) => {
        setVisibleReplies((prev) => ({
            ...prev,
            [commentId]: !prev[commentId],
        }));
    };

    return (
        <div className="commentsWrapper">
            {commentsList.map((comment) => (
                <div key={comment.commentId} style={{ marginLeft: "20px", marginBottom: "10px" }}>
                    <div>{comment.comment}</div>
                    <button onClick={() => handleVisibleReplies(comment.commentId)}>
                        {visibleReplies[comment.commentId] ? "hide replies" : "view replies"}
                    </button>
                    <button onClick={() => setActiveReplyBox(comment.commentId)}>
                        add reply
                    </button>
                    {activeReplyBox === comment.commentId && (
                        <AddComments
                            addCommentMessage={(value) => {
                                addCommentsReply(comment.commentId, value);
                            }}
                        />
                    )}
                    {visibleReplies[comment.commentId] && comment.isChild && (
                        <Comments
                            commentsList={comment.children}
                            addCommentsReply={addCommentsReply}
                            activeReplyBox={activeReplyBox}
                            setActiveReplyBox={setActiveReplyBox} // Pass down the setter function
                        />
                    )}
                </div>
            ))}
        </div>
    );
});

export default Comments;
