import React,{useState} from 'react'

const AddComments = ({ addCommentMessage=()=>{} }) => {
    const [input, setInput] = useState(null);
    const handleSubmit = () => {
        addCommentMessage(input);
        setInput("");
    }
  return (
      <div>
          <input placeholder='enter comments' onChange={(e) => setInput(e.target.value)} />
          <button onClick={handleSubmit}>submit</button>
      </div>
  )
}

export default AddComments