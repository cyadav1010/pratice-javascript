export const commentsData = [
    {
        commentId: 1,
        isChild: true,
        comment: "learn1 next js",
        children: [
            {
                commentId: 2,
                isChild: false,
                comment: "learn2 next js",
                children:[]
            },
            {
                commentId: 3,
                isChild: false,
                comment: "learn3 next js",
                children:[]
            }
        ]
    },
    {
        commentId: 4,
        isChild: true,
        comment: "learn4 next js",
        children: [
            {
                commentId: 5,
                isChild: false,
                comment: "learn5 next js",
                children:[]
            },
            {
                commentId: 6,
                isChild: false,
                comment: "learn6 next js",
                children:[]
            }
        ]
    }
]