import React from 'react'

const CommentsComp = ({ comment }) => {
    const [viewAll, setViewAll] = useState(false);
    return (
        <div>
            <div>{comment?.comment}</div>
            <button onClick={() => setViewAll(!viewAll)}>view replies</button>
            <button>add reply</button>
        </div>
    )
}

export default CommentsComp