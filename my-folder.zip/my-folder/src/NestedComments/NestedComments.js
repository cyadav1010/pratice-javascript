import React, { useState } from 'react'
import Comments from './Comments';
import { commentsData } from './commentsData';

const NestedComments = () => {
    const [commentsList, setComments] = useState(commentsData);
    const [activeReplyBox, setActiveReplyBox] = useState(null);
    const addCommentsReply = (id, message) => {
        console.log("addCommentsReply", id, message);
        let tempComments = JSON.parse(JSON.stringify(commentsList));
       tempComments = structuredClone(commentsList);
        dfsHelper(tempComments, id, message);
        console.log("tempComments", tempComments);
        setComments(tempComments);
        setActiveReplyBox(null);
    };
    const setReplyHandle = (value) => {
        setActiveReplyBox(value);
    }
    const dfsHelper = (Comments = [], id, message) => {
        Comments.forEach(comment => {
            if (comment?.commentId == id) {
                let obj = {
                    commentId: Date.now(),
                    isChild: false,
                    comment: message,
                }
                if (!comment.isChild) {
                    comment.isChild = true;
                    comment.children = [];
                }
                comment.children.push(obj);
            }
            if (comment?.children?.length > 0) {
                dfsHelper(comment.children, id, message);
            }
        });
    }
    return (
        <div>
            <Comments commentsList={commentsList} addCommentsReply={addCommentsReply} activeReplyBox={activeReplyBox}
                setActiveReplyBox={setActiveReplyBox} />
        </div>
    )
}

export default NestedComments