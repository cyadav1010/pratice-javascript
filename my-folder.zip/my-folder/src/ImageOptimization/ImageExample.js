import React from 'react'
import ProgressiveImage from './ProgressiveImage'

const ImageExample = () => {
    return (
        <div>
            <ProgressiveImage
                placeholderSrc="https://picsum.photos/200/300/?blur=2"
                src="https://picsum.photos/id/237/200/300"
                alt="Beautiful Landscape"
            />
        </div>
    )
}

export default ImageExample