import React, { useState, useEffect } from 'react'

const ProgressiveImage = ({ placeholderSrc, src, alt }) => {
    const [imageSrc, setImageSrc] = useState(placeholderSrc);
    const [isLoaded, setIsLoaded] = useState(false);
    useEffect(() => {
        const img = new Image();
        img.src = src;
        img.onload = () => {
            setImageSrc(src);
            setIsLoaded(true);
        }
    }, [src])
    return (
        <div>
            <img
                srcset="small.jpg 480w, medium.jpg 800w, large.jpg 1200w"
                sizes="(max-width: 600px) 480px, (max-width: 1000px) 800px, 1200px"
                loading='lazy'
                // loading='eager'
                src={imageSrc}
                alt={alt}
                style={{
                    filter: !isLoaded ? 'blur(10px)' : 'none'
                }}
            // style={{
            //     filter: !isLoaded ? 'blur(10px)' : 'none',
            //     transition: 'filter 0.5s ease-in-out',
            // }}
            />
            { }

            <>

                <picture>
                    <source srcset="image.webp" type="image/webp" media="(min-width: 1200px)"/>
                    <source srcset="image.jpg" type="image/jpeg" />
                    <img src="fallback.jpg" alt="Example Image" />
                </picture>
            </>
        </div>
    )
}

export default ProgressiveImage
