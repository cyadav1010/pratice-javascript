/*






*/
const domApp = {
    type: "div",
    props: { id: "abc" },
    children: [{ type: "h1", className:"main-container",children: "hellor" },{ type: "h1", children: "hellor" }]
}
function generateDom(domObj, entry) {
    const helper = (obj) => {
        const { type, props, children } = obj;
        const el = document.createElement(type);
        if (props) {
            for (let prop in props) {
                el[prop] = props[prop];
            }
        }
        if (typeof children === "string") {
            el.innerText = children;
            el.className = className;
        } else {

            const fragment = document.createDocumentFragment();
            for (let child of children) {
                el.appendChild(helper(child))
                // fragment.append(helper(child));
            }
            el.append(fragment);
        }
        return el;

    };
    const generatedDom = helper(domObj);
    entry.appendChild(generatedDom);
}
const entry = document.getElementById("root");
generateDom(domApp, entry)











const cutomDom = {
    type: "div",
    props: { id: abc },
    children: [{ type: "h1", children: "hello", }]
}



function generateDomHelper(domapp, entry) {
    const helperDfs=(obj)=>{
        const { type, props, children } = obj;
        const ele = document.createElement(type);
        if (typeof type == "string") {
            ele.innerText = children;
        } else {
            for (const child of children) {
                ele.append(helperDfs(child))
            }
           
        }
        return ele;
    }
    const element = helperDfs(obj);
    entry.appendChild(element);
}