import React,{useMemo} from 'react'


// 2d array convert into flattern array 
const Shape = ({data=[]}) => {
    const boxes = useMemo(() => data?.flat(Infinity), [data])
  return (
    <div>{boxes?.map((box,index)=>{
        return(
        <div

        />)
    })}</div>
  )
}

export default Shape