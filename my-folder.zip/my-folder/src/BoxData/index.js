import React,{useState,useEffect} from 'react'
import './boxData.css';
const BoxData = () => {
    const BOX_DATA=[
        [1,1,1],
        [1,0,0],
        [1,1,1]

    ];
    const boxes=[
        [0,0,0],
        [0,0,0],
        [0,0,0]

    ];
    const countAllOnes=(boxData)=>{
        let total=0;
        boxData?.forEach((box)=>{
            box?.forEach((ele)=>{
                if(ele==1){
                    total+=1;
                }
            })
        })
        return total
        
    };
    const [boxOrder, setBoxOrder] = useState(boxes);
    const [history, setHistory] = useState([]);
    const [total, setTotal] = useState(0);
    const checkAllSelected=()=>{
        boxOrder?.forEach((box)=>{
            box?.forEach((ele)=>{
            })
        })
    };
    const handleClickBox=(rowIndex,colIndex)=>{
        console.log("rowIndex,colIndex",rowIndex,colIndex)
        let boxOrderTemp =[...boxOrder];
        if(boxOrderTemp[rowIndex][colIndex]!=1){
        boxOrderTemp[rowIndex][colIndex] = 1;
        setBoxOrder(boxOrderTemp);
        let tempHistory=[...history];
        tempHistory.push([rowIndex,colIndex]);
        setHistory(tempHistory);
        }
    };
    useEffect(() => {
      const total = countAllOnes(BOX_DATA);
        setTotal(total);
    }, []);
    const deSelectBox = () => {
        history.forEach((ele, index) => {
            setTimeout(() => {
                setBoxOrder((prevBoxOrder) => {
                    const updatedBoxOrder = [...prevBoxOrder];
                    updatedBoxOrder[ele[0]][ele[1]] = 0;
                    return updatedBoxOrder;
                });
            }, index * 500);
        });
        setHistory([]); 
    };
    
    useEffect(() => {
        const currTotals = countAllOnes(boxOrder);
        if(currTotals==total){
            deSelectBox();
        }
    }, [boxOrder])
  return (
    <div>
        {BOX_DATA?.map((data,rowIndex)=>
        { return(
        <div key={rowIndex}  className='row'>
            {data?.map((ele,colIndex)=>( ele >= 1 ? <div  key={colIndex} 
            className={`box ${boxOrder[rowIndex][colIndex] ==1 ? 'selected': ''}`} 
            onClick={()=>handleClickBox(rowIndex,colIndex)}>{ele}</div> : null))}
        </div>
        )
        }
        )}
    </div>
  )
}

export default BoxData