import React,{useState, useEffect} from 'react'
import './style.css';
const AnimatedCircles = () => {
    
    const hexColors = [
        "#00FFFF", // Aqua
        "#000000", // Black
        "#0000FF", // Blue
        "#FF00FF", // Fuchsia
        "#808080", // Gray
        "#008000", // Green
        "#00FF00", // Lime
        "#800000", // Maroon
        "#000080", // Navy
        "#808000", // Olive
        "#800080", // Purple
        "#FF0000", // Red
        "#C0C0C0", // Silver
        "#008080", // Teal
        "#FFFF00"  // Yellow
      ];
      
    const [circles, setCircles] = useState([]);
    const [undoData, setUndoData] = useState([]);
    const [redo, setRedo] = useState([]);
    const handleClickCircle=(event)=>{
        const container = event.currentTarget; // The `.animatedCircles` element
        const rect = container.getBoundingClientRect(); // Container's bounding box
        // console.log("event===>",event.clientX,event.clientY);
        let colorList= hexColors?.length;
        let rnd =Math.floor(Math.random()*colorList);
        console.log("rnd====>>>",rnd);
        const newCircle={
            x:event.clientX -rect.left,
            y:event.clientY -rect.top,
            color: hexColors[rnd]
        }
      setCircles([...circles, newCircle]);
    };
    const handleReset =()=>{
        setCircles([]);
    };
    const handleRedo =()=>{
        let undoTemp=[...undoData];
        let lastData = undoTemp.pop();
        setTimeout(() => {
            setCircles([...circles, lastData]);
            setUndoData(undoTemp);
        }, 100);
    };
    const handleUndo =()=>{
        let circlesTemp =[...circles];
        let len = circlesTemp?.length ;
        let lastData = circles[len-1];// circlesTemp.shift();
        setTimeout(() => {
            setUndoData([...undoData,lastData]);
        circlesTemp.pop();
        setCircles(circlesTemp);
        }, 100);
    }
    useEffect(() => {
        console.log("circles",circles);
    }, [circles])
    
    var constructTransformedArray = function (nums) {
        let rightShift = 0;
        let leftShift = 0;
        let moveRight = true;
        let len = nums.length;
        let resultArr = [...nums];
        console.log("resultArr", resultArr);
        let indextoUpdate = 0;
        for (let i = 0; i < nums.length; i++) {
            rightShift = 0;
            leftShift = 0;
            if (nums[i] > 0) {
                moveRight = true;
                let totalShift = nums[i] % len;
                if (totalShift > len - i) {
                    leftShift = totalShift - (len - i);
                    if (leftShift - 1 >= 0) {
                        console.log("updating1 ");
                        // resultArr[leftShift - 1] = nums[i];
                        resultArr[i] = nums[leftShift];
                    }
                } else {
                    rightShift = i + totalShift;
                    if (rightShift < len) {
                        console.log("updating2 ");
                        // resultArr[rightShift] = nums[i];
                        resultArr[i] = nums[rightShift];
                    }
                }
            } else {
                moveRight = false;
                let totalShift = Math.abs(nums[i]) % len;
                if (totalShift > i) {
                    console.log("updating3 ");
                    rightShift = totalShift - i;
                    // resultArr[len-rightShift]=nums[i]
                    resultArr[i] = nums[len - rightShift];
                } else {
                    console.log("updating4 ", nums[i], i);
                    leftShift = totalShift;
                    // resultArr[i-leftShift]= nums[i];
                    resultArr[i] = nums[i - leftShift];
                }
            }
        }
        return resultArr;
    };
    // constructTransformedArray([-9,-3,8]);
  return (
    <div>
        Animated Circles
            <button onClick={()=>handleUndo()}>Undo</button>
            <button onClick={()=>handleRedo()}>Redo</button>
            <button onClick={()=>handleReset()}>Reset</button>
        <div className='animatedCircles' onClick={(e)=>handleClickCircle(e)}>
            {circles?.map((circle,index)=>{return <div 
                    key={index} 
                    style={{
                        width:'40px',
                        height:"40px",
                        position: "absolute",
                        borderRadius: "50%",
                        backgroundColor: `${circle?.color}`,
                        left: `${circle.x - 20}px`,
                        top: `${circle.y - 20}px`,
                    }}
                    
                    >
                    {/* {circle.x} , {circle.y} */}
            </div>
        })}
        </div>    
    </div>
  )
}

export default AnimatedCircles