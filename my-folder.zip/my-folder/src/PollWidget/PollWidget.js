import React from 'react'

const PollWidget = () => {
  return (
    <div>PollWidget</div>
  )
}

export default PollWidget