export const pollData = [{
    id: "123",
    question: "what is your favorite Javascript library/frameworks",
    totalCount:0,
    options: [
        {
            id: 1,
            count: 0,
            perCentage: 0,
            title: "next js"
        },
        {
            id: 2,
            count: 0,
            perCentage: 0,
            title: "vue js"
        },
        {
            id: 2,
            count: 0,
            perCentage: 0,
            title: "react js"
        }
    ],
    answer: []
}];