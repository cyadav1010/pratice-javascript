import React, { useState } from 'react'
import Pagination from './Pagination'

const PaginatedList = ({ items = [], itemsPerPage }) => {
    const [currentItems, setCurrentItems] = useState([])
    const itemSize = items?.length;
    const handleOnPageChange = (currentPage) => {
        console.log("currentPage==>", currentPage);
        let tempItems = [];
        let startIndex = currentPage * itemsPerPage;
        for (let i = startIndex; i < startIndex+itemsPerPage; i++) {
            tempItems.push(items[i]);
        }
        setCurrentItems(tempItems);
     }
    return (
        <div>
            {currentItems?.length > 0 && currentItems?.map((ele) => {
                return (<div>{ele?.item}</div>)
            })}
            <Pagination itemSize={itemSize} itemsPerPage={itemsPerPage} handleOnPageChange={handleOnPageChange} />
        </div>
    )
}

export default PaginatedList