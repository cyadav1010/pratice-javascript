import React, { useState } from 'react'
import PaginatedList from './PaginatedList';
import './style.css';

const PaginationWrapper = () => {
    const largeList = Array.from({ length: 1000 }, (_, index) => ({ id: index + 1, item: `Item ${index + 1}` }))
    const [items, setItems] = useState(largeList);

    return (
        <div>
            <PaginatedList items={largeList} itemsPerPage={10} />
        
        </div>
    )
}

export default PaginationWrapper