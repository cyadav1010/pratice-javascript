import React, { useState, useEffect } from 'react'

const Pagination = ({ itemSize, itemsPerPage, handleOnPageChange = () => { } }) => {
    const [currentPage, setCurrentPage] = useState(1);
    const totalNoOfPages = Math.ceil(itemSize / itemsPerPage);
    const handlePageChange = (value) => {
        if (value < 0) {
            setCurrentPage(0);
        }
        setCurrentPage(value);
    }
    useEffect(() => {
        handleOnPageChange(currentPage);
    },[currentPage])
    const handleNextPage = () => {
        if (currentPage == totalNoOfPages) {
            return null;
        } else {
            handlePageChange(currentPage + 1);
        }
    }
    const handlePrevPage = () => {
        if (currentPage == 1) {
            return;
        } else {
            handlePageChange(currentPage - 1);
        }
    }
    const pageNumbers = [];
    for (let i = 0; i < totalNoOfPages; i++) {
        pageNumbers.push(i+1);
    }
    const renderPageNoCheck = (pageNo) => {
        if (pageNo + 1 == currentPage || pageNo - 1 == currentPage || pageNo == currentPage || pageNo == totalNoOfPages || pageNo == 1)
            return true;
        else
            return false;
    }
    return (
        <div className='PaginationWrapper'>
             <button onClick={() => handlePrevPage()}>prev</button>
            {pageNumbers?.map((pageNo) => {
                if (renderPageNoCheck(pageNo))
                    return (<button className={`${currentPage == pageNo ? "activePage" : ""}`} onClick={() => handlePageChange(pageNo)}>{pageNo}</button>);
                else
                    return null;
            })}
            <button onClick={() => handleNextPage()}>next</button>
        </div>
    )
}

export default Pagination