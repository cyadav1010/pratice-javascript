import { useState, useCallback } from 'react'
const useToggle = (initalValue = false) => {
    const [value, setValue] = useState(initalValue);

    const toggle = useCallback(() => {
        setValue(!value);
    }, [value])
    return [value, toggle]
};

export default useToggle;