import React,{useId} from 'react'
import useToggle from './useToggle';

const ModalExample = () => {
    const id = useId();
    console.log("id==>", id);
    const [isModalOpen, toggleModal] = useToggle(false);
    const handleParentClick = (e) => {
        if (e.target === e.currentTarget) {
            console.log("handleParentClick");
        }
    }
    const handleBtnClick = (e) => {
        if (e.target === e.currentTarget) {
            console.log("handleBtnClick");
            e.stopPropagation();
            // toggleModal();
        }
        // stopPropagation();
    }
    return (
        <div>
            <div onClick={handleParentClick}>
            <button onClick={(e)=>handleBtnClick(e)}>
                {isModalOpen? "close modal":"open modal"}
                </button>
                </div>
        </div>
    )
}

export default ModalExample