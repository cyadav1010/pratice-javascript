import React from "react"
const useOnClickOutside = (ref, handler) => {

    useEffect(() => {
        const handleMouseDown = (event) => {
            if (ref.current && ref.current.contains(event.target)) {
                handler(event);
            }
            return;

        }
        const handleMouseUp = (event) => {
            if (ref.current && ref.current.contains(event.target)) {
                return handler(event);
            }
        }
        document.addEventListener("mousedown", handleMouseDown);
        document.addEventListener("mouseup", handleMouseUp);
        return () => {
            document.removeEventListener("mousedown", handleMouseDown);
            document.removeEventListener("mouseup", handleMouseUp);
        }
    }, [ref, handler])
}