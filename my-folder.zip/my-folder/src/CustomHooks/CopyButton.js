import React from 'react'
import useCopy from './useCopy';

const CopyButton = () => {
     const [copied, copyToClipboard] = useCopy();
  return (
      <div>
          <button onClick={()=>copyToClipboard("https://google.com")}>
              {copied ? 'Copied!' : 'Copy URL'}
          </button>
    </div>
  )
}

export default CopyButton