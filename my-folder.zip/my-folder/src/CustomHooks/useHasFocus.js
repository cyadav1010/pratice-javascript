
import { useState } from 'react';
const useHasFocus = (ref) => {
    const [hasFocus, setHasFocus] = useState(false);
    useEffect(() => {
        if (!ref.current) return;
        const element = ref.current;
        const onFocus = () => setHasFocus(true);
        const onBlur = () => setHasFocus(false);
        element.addEventListener('focus', onFocus);
        element.addEventListener('blur', onBlur);
        return () => {
            element.removeEventListener('focus', onFocus);
            element.removeEventListener('blur', onBlur);
        }
    }, [ref]);
    return hasFocus;
}
export default useHasFocus;


const useFocus