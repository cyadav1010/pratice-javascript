import React from 'react'
import usePrevious from '../Programming/usePrevious';

const HooksExample = () => {
    const [count, setCount] = useState(0);
  const prevCount =  usePrevious(count);
  return (
      <div>
          current: {count} previousValue :{prevCount}
          <button onClick={()=>{setCount(count+1)}}>sumit</button>
    </div>
  )
}

export default HooksExample