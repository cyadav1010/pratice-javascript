import { useState } from "react";

const useCopy = () => {
    const [copied, setCopied] = useState(false)
    const copyToClipboard = async (text) => {
        try {
            await navigator.clipboard.writeText(text);
            setCopied(true);
            setTimeout(() => setCopied(false), 2000);
        } catch (error) {
            console.log("failed to copy");
        }
    }
    return [copied, copyToClipboard];
}
export default useCopy;