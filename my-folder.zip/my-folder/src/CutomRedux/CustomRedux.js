// Store : Holds the state of the application.
// Reducer : A function that determines how the state changes in response to actions.
// Actions : Plain JavaScript objects that describe what happened (e.g., { type: 'INCREMENT' }).
// Dispatch : A method to send actions to the store, triggering state updates.
// Subscribe : A method to listen for state changes.


class Store {
    constructor(reducer, initialState = {}) {
        this.reducer = reducer;
        this.state = initialState;
        this.listeners = [];
        this.dispatch({ type: '@@INIT' });
    }
    // Get the current state
    getState() {
        return this.state;
    }
    // 
    dispatch(actions) {
        this.state = this.reducer(this.state, actions);
        this.listeners.forEach(listener =>
            listener()
        );
    }
    subscribe(listener) {
        this.listeners.push(listener);
        // // Return an unsubscribe function
        return () => {
            this.listeners = this.listeners.filter((lis) => lis != listener);
        }
    }
}

const initialState = {
    count: 0
}

const initialTextState = {
    text: ""
}
function anotherReducer(state = initialTextState, action) {
    switch (action.type) {
        case 'CHANGE_TEXT':
            return { ...state, text: action.payload };
        default:
            return state;
    }
}

const counterReducer = (state = initialState, action) => {
    switch (action.type) {
        case "INCREMENT":
            return { ...state, count: state.count + 1 }
        case "DECREMENT":
            return { ...state, count: state.count - 1 }
        default:
            return state
    }
}

function combineReducers(reducers) {
    return function combinedReducer(state = {}, action) {
        const newState = {};
        for (let key in reducers) {
            newState[key] = reducers[key](state[key], action);
        }
        return newState;
    };
}

const rootReducer = combineReducers({
    count: counterReducer,
    text: anotherReducer
});

console.log("rootReducer", rootReducer);
const store = new Store(rootReducer);

function logState() {
    console.log('Current state:', store.getState());
}

logState();

const unsubscribe = store.subscribe(logState);

store.dispatch({ type: 'INCREMENT' }); // Output: Current state: { count: 1 }
store.dispatch({ type: 'INCREMENT' }); // Output: Current state: { count: 2 }
store.dispatch({ type: 'DECREMENT' }); // Output: Current state: { count: 1 }



const initailStateData = {
    data: null,
    loading: null,
    error: null,
}

function reducer(state = initailStateData, actions) {
    switch (actions.type) {
        case "FETCH_DATA_START":
            return { ...state, loading: true, error: false };

        case "FETCH_DATA_SUCCESS":
            return { ...state, loading: false, error: false, data: actions.payload }
        case "FETCH_DATA_FAIL":
            return { ...state, loading: false, error: actions.error }
        default:
            return state;
    }
}
const fetchData = () => {
    return async (dispatch, getState) => {
        dispatch({ type: "FETCH_DATA_START" })
        try {
            // make api call 
            const response = await fetch('https://api.example.com/data');
            const data = await response.json();
            dispatch({ type: "FETCH_DATA_SUCCESS", data })
        } catch (error) {
            dispatch({ type: "FETCH_DATA_ERROR", Error })
        }
    }
}


store.dispatch(fetchData());

// Final State: { count: 0, user: { name: 'Anonymous' } }
// Dispatching an Action
// Consider dispatching { type: 'INCREMENT', payload: 3 }.

// Combined Reducer Invocation

// javascript
// Copy
// combinedReducer({ count: 0, user: { name: 'Anonymous' } }, { type: 'INCREMENT', payload: 3 });
// Processing Each Reducer
// combonedReducer({count:0,user:},{type:"increment",payload:3})
// Counter Reducer

// javascript
// Copy
// counterReducer(0, { type: 'INCREMENT', payload: 3 }); // Returns 3
// User Reducer

// javascript
// Copy
// userReducer({ name: 'Anonymous' }, { type: 'INCREMENT', payload: 3 }); // Returns { name: 'Anonymous' }
// Constructing New State

// javascript
// Copy
// newState = {
//   count: 3,
//   user: { name: 'Anonymous' },
// };
// State Update

// The store's state is now { count: 3, user: { name: 'Anonymous' } }.



// AbortController()

function fecthWithTimeout(url, options, duration) {
    const controller = new AbortController();
    const signal = controller.signal;
     let timerId = null;
    timerId = setTimeout(() => {
        controller.abort();
    }, duration);
    return new Promise((resolve, rejected) => {
        fetch(url, { signal })
            .then((res) => {
                clearTimeout(timerId)
                res.json().then((res) => {
                    resolve(res);
                })
            })
            .catch((err) => rejected(err))
    })
}


