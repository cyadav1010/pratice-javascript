
// global store across the apps
// dispatc the action
// render on ui means callback subscribe  function



class store {
    constructor(reducer) {
        this.state = [];
        this.reducer = reducer;
        this.listeners = [];
        this.dispatch({type:"init"})
    }
    getState(){
        return this.state;
    }
    dispatch(actions) {
        this.state = this.reducer(this.state, actions);
        this.listeners.forEach((lis) => { lis() });
    }
    subscribe(listener) {
        this.listeners.push(listener);
        return () => {
            this.listeners = this.listeners.filter((lis) => lis != listener);
        }
    }
}
const initalState = {
    count: 0
}
const counterReducer = (state = initalState, actions) => {
    switch (actions.type) {
        case "increment":
            return { ...state, count: state.count + 1 };
        case "decrement":
            return { ...state, count: state.count - 1 };
        default:
            return state;
    }
}
// combine multiple reducer
const combineReducers = (reducers) => {
    return function combineReducer(state={},actions) {
        let newState = {};
        for (let key in reducers) {
            newState[key] = reducers[key](state[key], actions);
        }
        return newState;
    }
}

const loginReducer = (state,actions) => {
    
}
const rootReducer = combineReducers({
    count: counterReducer,
    login:loginReducer
})