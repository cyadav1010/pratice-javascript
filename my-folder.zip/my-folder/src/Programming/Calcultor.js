import React, { useState } from "react";
import "./App.css";

function Calculator() {
  const [input, setInput] = useState(""); // Stores the current input
  const [result, setResult] = useState(""); // Stores the result of the calculation

  // Handle button clicks
  const handleClick = (value) => {
    if (value === "=") {
      try {
        // Evaluate the expression and update the result
        setResult(eval(input).toString());
      } catch (error) {
        setResult("Error");
      }
    } else if (value === "C") {
      // Clear the input and result
      setInput("");
      setResult("");
    } else {
      // Append the clicked value to the input
      setInput((prevInput) => prevInput + value);
    }
  };

  return (
    <div className="calculator">
      <h1>React Calculator</h1>
      <div className="display">
        <input type="text" value={input} readOnly />
        <div className="result">{result}</div>
      </div>
      <div className="buttons">
        {/* Digits */}
        {[7, 8, 9, 4, 5, 6, 1, 2, 3, 0].map((digit) => (
          <button key={digit} onClick={() => handleClick(digit)}>
            {digit}
          </button>
        ))}
        {/* Operators */}
        {["+", "-", "*", "/"].map((operator) => (
          <button key={operator} onClick={() => handleClick(operator)}>
            {operator}
          </button>
        ))}
        {/* Special Buttons */}
        <button onClick={() => handleClick("C")} className="clear">
          C
        </button>
        <button onClick={() => handleClick("=")} className="equals">
          =
        </button>
      </div>
    </div>
  );
}

export default Calculator;