// import React,{useState,useEffect,useRef} from 'react'
// import './lightStyle.css';

// const light = [{ color: "red", duration: 4000 }, { color: "yellow", duration: 1000 }, { color: "green", duration: 2000 }]
// const Trafficlights = () => {
//     const [lights, setlights] = useState(light);
//     const [activeIndex, setActiveIndex] = useState(0);
//     const timerId = useRef(null);
//     // const startTimer = () => {
//     //     if (timerId.current) {
//     //         clearInterval(timerId.current);
//     //     }
//     //     let delay = lights[activeIndex];
//     //    timerId.current= setInterval(() => {
//     //         setActiveIndex((prev) => {
//     //             let val = (prev + 1) % 3;
//     //             return val;
//     //         })
//     //     }, delay.duration);
//     // }
//       const startTimer = () => {
//     if (timerId.current) {
//       clearInterval(timerId.current);
//     }

//     // Set the interval and assign it to timerId.current
//     timerId.current = setInterval(() => {
//       setActiveIndex((prev) => (prev + 1) % lights.length);
//     }, lights[activeIndex].duration);
//   };
//     useEffect(() => {
//         startTimer();
//         return () => clearInterval(timerId.current);
//     }, [activeIndex])
//     return (
//         <div>
//             {lights?.map((ele, index) => {
//                 return (<div className={`light`} style={{ backgroundColor: index == activeIndex ? ele.color : "" }}></div>)
//             })}
//         </div>
//     )
// }

// export default Trafficlights