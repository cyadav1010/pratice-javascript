function memoize(func) {
    let cache = {};
    return function (...args) {
        let key = JSON.stringify(args);
        if (cache.hasOwnProperty(key)) {
            return cache[key];
        }
        const outputValue = func(...args);
        cache[key] = outputValue;
        return outputValue;
    }
}