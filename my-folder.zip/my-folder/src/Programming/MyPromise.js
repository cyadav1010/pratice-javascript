class MyPromise {
  constructor(executor) {
    this.state = 'pending'; // States: pending, fulfilled, rejected
    this.value = undefined; // Resolved value or rejection reason
    this.callbacks = []; // To store then/catch handlers

    const resolve = (value) => {
      if (this.state === 'pending') {
        this.state = 'fulfilled';
        this.value = value;
        this.callbacks.forEach((callback) => this.handleCallback(callback));
      }
    };

    const reject = (reason) => {
      if (this.state === 'pending') {
        this.state = 'rejected';
        this.value = reason;
        this.callbacks.forEach((callback) => this.handleCallback(callback));
      }
    };

    try {
      executor(resolve, reject);
    } catch (error) {
      reject(error);
    }
  }

  then(onFulfilled, onRejected) {
    return new MyPromise((resolve, reject) => {
      this.handleCallback({
        onFulfilled: typeof onFulfilled === 'function' ? onFulfilled : (value) => value,
        onRejected: typeof onRejected === 'function' ? onRejected : (reason) => { throw reason; },
        resolve,
        reject
      });
    });
  }

  catch(onRejected) {
    return this.then(null, onRejected);
  }

  handleCallback(callback) {
    if (this.state === 'pending') {
      this.callbacks.push(callback);
      return;
    }

    const cb = this.state === 'fulfilled' ? callback.onFulfilled : callback.onRejected;

    try {
      const result = cb(this.value);
      callback.resolve(result);
    } catch (error) {
      callback.reject(error);
    }
  }

  static resolve(value) {
    if (value instanceof MyPromise) {
      return value;
    }
    return new MyPromise((resolve) => resolve(value));
  }

  static reject(reason) {
    return new MyPromise((_, reject) => reject(reason));
  }

  static all(promises) {
    return new MyPromise((resolve, reject) => {
      let results = [];
      let completed = 0;

      promises.forEach((promise, index) => {
        MyPromise.resolve(promise).then((value) => {
          results[index] = value;
          completed += 1;
          if (completed === promises.length) {
            resolve(results);
          }
        }).catch(reject);
      });
    });
  }

  static race(promises) {
    return new MyPromise((resolve, reject) => {
      promises.forEach((promise) => {
        MyPromise.resolve(promise).then(resolve).catch(reject);
      });
    });
  }
}

// Example usage:
const promise1 = new MyPromise((resolve, reject) => {
  setTimeout(() => resolve('Resolved after 1 second'), 1000);
});

promise1.then((value) => {
  console.log(value); // "Resolved after 1 second"
});



class MyPromiseFun {
  constructor(executor) {
    this.state = "pending";
    this.value = undefined;
    this.callbacks = [];
    const resolve = (value) => {
      if (this.state === 'pending') {
        this.state = 'fulfilled';
        this.value = value;
        this.callbacks.forEach((callback) => callback(value));
      }

    }
    executor(resolve);
  }
  then(onFulfilled) {
    if (this.state === "fulfilled") {
      onFulfilled(this.value);
    } else {
      this.callbacks.push(onFulfilled);
    }
    return this;
  }
  all(promises) {
    return new MyPromiseFun((resolve) => {
      const result = [];
      let completed = 0;
      promises.forEach((promise, index) => {
        promise.then((value) => {
          result[index] = value;
          completed += 1;
          if (completed == promises.length) {
            resolve(result);
          }
        })

      })
    })
  }
}

const promise3 = new MyPromiseFun((resolve) => {
  setTimeout(() => {
    resolve("hello world");
  }, 1000);
});
promise3.then((value) => console.log("value", value))


Promise.myAllPromise = function (promises) {
  return new Promise((resolve, reject) => {
    let result = new Array(promises.length);
    if (promises.length == 0) {
      resolve(result);
    }
    let counter = 0;
    for (let i = 0; i < promises.length; i++) {
      Promise.resolve(promises[i]).then((data) => {
        result[i] = data;
        counter++;
        if (counter == promises.length) {
          resolve(result);
        }
      })
        .catch(reject);
    }
  })
}




class myCustomPromise {
  constructor(executor) {
    this.value = null;
    this.callback = [];  // List of callbacks for successful fulfillment.
    this.state = "pending";// current state of promise
    this.reason = null;
    this.errorCallbacks = [];
    const resolve = this.resolve.bind(this);
    const reject = this.reject.bind(this);
    try {
      executor(resolve, reject)
    } catch (error) {

    }
  }
  resolve(value) {
    if (this.state == "pending") {
      this.state = "fulfilled";
      this.value = value;
      this.callback.forEach((cb) => cb(value));
    }
  }
  then(onFullFillment) {
    if (this.state == "fullfilled") {
      onFullFillment(this.value);
    }
    else {
      this.callback.push(onFullFillment);
    }
  }
  catch(onRejected) {
    if (this.state == "rejected") {
      onRejected(this.reason);
    } else if (this.state == "pending") {
      this.errorCallbacks.push(onRejected);
    }
    return this;
  }
  reject(reason) {
    if (this.state == "pending") {
      this.state == "rejected";
      this.reason = reason;
      this.errorCallbacks.forEach((cb) => cb(reason));
    }
  }
}


function sayHello(greeting,text="") {
  console.log(`${greeting} ${this.name} ${text}` )
}
const person = { name: "chandan" };
sayHello.call(person, "HI");


sayHello.apply(person, ["HI", "yadav"]);



function sum(a, b, c) {
  return a + b + c;
}
let arr = [1, 2, 3];
sum.apply(null, arr);


function greet() { return `Hello, ${this.name}`; }
const person1 = { name: 'Devtools Tech' };
const boundGreet = greet.bind(person1);
boundGreet(); // "Hello, Devtools Tech"