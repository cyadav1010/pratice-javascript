// import React, { useState, useEffect, useCallback } from "react";

// const DebounceExample = () => {
//     const [input, setInput] = useState(null);
//     const [data, setData] = useState(null);

//     const debounceFun = (func, delay) => {
//         let timerId = null;
//         console.log("func", func);
//         return function (...args) {
//             console.log("timerId", timerId);
//             console.log("args==>>", args);
//             clearTimeout(timerId);
//             timerId = setTimeout(() => {
//                 func(args);
//             }, delay);
//         };
//     };
//     const apiCall = (value) => {
//         console.log("api calling from backend", value);
//         setData(value);
//     }
//     const callDebounceFunc = useCallback(debounceFun(apiCall, 2000), []);
//     const handleOnChange = (value) => {
//         setInput(value);
//         console.log("callDebounceFunc", callDebounceFunc);
//         callDebounceFunc(value);
//     };
//     useEffect(() => {
//         console.log("data===>>", data);
//     }, [data])
//     return (
//         <div>
//             <input onChange={(e) => handleOnChange(e.target.value)} value={input} />
//         </div>
//     );
// };

// export default DebounceExample;


// const DebounceExample = () => {
//     const [input, setInput] = useState("");

//     const debounceFun = (func, delay) => {
//         let timerId; // Recreated on every render
//         return (...args) => {
//             clearTimeout(timerId);
//             timerId = setTimeout(() => func(...args), delay);
//         };
//     };

//     const handleChange = debounceFun((value) => {
//         console.log("Value:", value);
//     }, 2000);

//     return (
//         <input
//             onChange={(e) => handleChange(e.target.value)}
//             value={input}
//             placeholder="Type something"
//         />
//     );
// };

// export default DebounceExample;

import React, { useState, useRef } from "react";

const DebounceExample = () => {
    const [input, setInput] = useState("");
    const timerId = useRef(null); // Use useRef at component scope

    const debounceFun = (func, delay) => {
        return (...args) => {
            if (timerId.current) {
                clearTimeout(timerId.current); // Clear previous timer
            }

            timerId.current = setTimeout(() => {
                func(...args); // Execute the function
            }, delay);
        };
    };

    const handleChange = debounceFun((value) => {
        console.log("Value:", value);
        setInput(value);
    }, 2000);

   
    const debounceFunEx = (func, delay) => {
        return (...args) => {
            if (timerId.current) {
                clearTimeout(timerId.current); // Clear previous timer
            }
            timerId.current = setTimeout(() => {
                func(...args);
            }, delay)
        }
    }
    function debounce(func, wait, immediate) {
        let timeout;
        return function (...args) {
            const context = this;
            const callNow = immediate && !timeout;
            clearTimeout(timeout);
            timeout = setTimeout(() => {
                timeout = null;
                if (!immediate) func.apply(context, args)
            }, wait);
            if (callNow) func.apply(context, args);
        }
    }

    let timerIdRef = useRef(null);
    const customDebounce = (func, delay) => { 
        return (...args) => {
            if (timerIdRef.current) {
                clearTimeout(timerIdRef);
            }
            timerIdRef.current = setTimeout(() => {
                func(...args);
             }, delay);
        }
    };
    let timerIdDebounceRef = useRef(null);
    const customMyDebounce = (func, delay) => {
        return (...args) => {
            if (timerIdDebounceRef.current) {
                clearTimeout(timerIdDebounceRef);
            }
            timerIdDebounceRef.current=setTimeout(() => {
                func(...args);
            }, delay); 
        }
    }

    const myThtrottle = (func, limit) => {
        let lastRun = 0;
        return (...args) => {
            let currentRun = Date.now();
            if (currentRun - lastRun >= limit) {
                lastRun = Date.now();
                func.apply(this, ...args);
            }
        }
        
    }
    const customThrottle = (func, limit) => {
        let lastRun = 0;
        return function (...args){
            let curTime = Date.now();
            if (curTime - lastRun >= limit) {
                lastRun = Date.now();
                func.apply(this,args);
            }
        }
    }
    const handleOnChangede = debounceFun((value) => {
        console.log("Value:", value);
        setInput(value);
    },200)
    return (
        <input
            onChange={(e) => handleChange(e.target.value)}
            value={input}
            placeholder="Type something"
        />
    );
};

export default DebounceExample;

