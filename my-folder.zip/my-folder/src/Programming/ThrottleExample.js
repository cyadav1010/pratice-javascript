import React, { useState, useCallback, useEffect } from "react";
const ThrottleExample = () => {
    const [count, setCount] = useState(0);
    const throttle = (func, limit) => {
        // console.log("func", func);
        // console.log("limit", limit);
        let lastRun = 0;
        return function (...args) {
            // console.log("args", args);
            let currTime = Date.now();
            if (currTime - lastRun >= limit) {
                lastRun = Date.now();
                func.apply(this, args);
            }
        };
    };
    const inCrementCount = (value) => {
        setCount(value);
    };
    const handleScroll = () => {
        console.log("Scroll event triggered at:", new Date().toLocaleTimeString());
    }
    const throttleFun = useCallback(throttle(inCrementCount, 2000), [])
    const handleClick = () => {
        let tempCount = count;
        console.log("throttleFun", throttleFun);
        throttleFun(tempCount + 1);
    };
    useEffect(() => {
        const throttledScroll = throttle(handleScroll, 2000);
        window.addEventListener('scroll', throttledScroll);
        return () => {
            window.removeEventListener('scroll', throttledScroll);
        }
    }, [])
    return (
        <div style={{ height: "200vh" }}>
            <h1>Scroll down to see throttle in action!</h1>
            <button onClick={() => handleClick()}>click me : {count}</button>
        </div>
    );
};

export default ThrottleExample;
