class MyPromise {
  constructor(executor) {
    this.state = 'pending';
    this.value = null;
    this.callbacks = [];

    const resolve = (value) => {
      if (this.state === 'pending') {
        this.state = 'fulfilled';
        this.value = value;
        this.callbacks.forEach((callback) => callback(value));
      }
    };

    try {
      executor(resolve);
    } catch (err) {
      console.error(err);
    }
  }

  then(onFulfilled) {
    if (this.state === 'fulfilled') {
      onFulfilled(this.value);
    } else {
      this.callbacks.push(onFulfilled);
    }
    return this;
  }
}

// Example usage:
const promise = new MyPromise((resolve) => {
  setTimeout(() => resolve('Hello, World!'), 1000);
});

promise.then((value) => console.log(value)); // "Hello, World!"



const myPromise1 = new Promise((resolve, reject) => {
  setTimeout(() => {
    resolve("foo");
  }, 300);
});

const myPromise2 = new Promise((resolve, reject) => {
    setTimeout(() => {
        resolve("chandan");
    },300)
})