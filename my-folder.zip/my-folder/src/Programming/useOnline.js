function useOnlineStatusWithRefresh() {

    const [isOnline, setIsOnline] = useState(navigator.onLine);

    useEffect(() => {
        const hasOnline = () => {
            setIsOnline(true);
            window.location.reload();
        }
        const hasOffline = () => setIsOnline(false);
        window.addEventListener("online", hasOnline);
        window.addEventListener("offline", hasOffline);
        return () => {
            window.removeEventListener("online", hasOnline);
            window.removeEventListener("offline", hasOffline);
        }
    }, [])
    return isOnline;
}

export default useOnlineStatusWithRefresh;










const useOnline = () => {
    const [isOnline, setisOnline] = useState(navigator.onLine);
    const hasOnline = () => {
        setisOnline(navigator.onLine)
    }
    useEffect(() => {
        window.addEventListener("online", hasOnline);
        window.addEventListener("offline", hasOnline);
        return () => {
            window.removeEventListener("online", hasOnline);
            window.removeEventListener("offline", hasOnline);
        }
    }, [])
    return { isOnline };
}
















