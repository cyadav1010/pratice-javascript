// import React from 'react'

// const CodingTest = () => {

    const object = {
        length: 5,
        method() {
            arguments[0]();
        },
    };
    function callback1() {
        const myLength = this.length;
        var i;
        for (i = 0; i < myLength; i++) { 
            setTimeout(() => console.log("timeout", i)); // 
            const myPromise = new Promise((resolve) => { resolve(i); });// 
            myPromise.then((data) => console.log("promise", data));// 
        }
    };

object.method(callback1, 1, 2);
 
//     // setTimeout(() => console.log("timeout", 1));
//     // // promise 5 
//     // // promise 5
//     // // promise 5
//     // // promise 5
//     // // promise 5
//     // // timeout 5
//     // // timeout 5
//     // // timeout 5
//     // // timeout 5
//     // // timeout 5
   
//     async function fetchWithRetry(url, options, retryTimes) {
//         while (retryTimes >= 0) {
//             console.log("retryTimes", retryTimes);
//             if (retryTimes < 0) {
//                 return new Promise((resolve, rejected) => rejected("retry finised"));
//             }
//             try {
//                 const resData = await fetch(url, options);
//                 const responseData = await resData.json();
//                 console.log("responseData==>", responseData);
//                 // if(resData?.)
//                 if (Object.keys(responseData)?.length > 0) {
//                     console.log("returning");
//                     return new Promise((resolve) => resolve(resData));
//                 } else {
//                     console.log("retryTimes--");
//                     retryTimes--;
//                 }
//                 // if (resData?.success) {
//                 //     return new Promise((resolve) => resolve(resData));
//                 // }
//             } catch (error) {
//                 retryTimes--;
//             }
//         }
//     }

//     fetchWithRetry("https://jsonplaceholder.typicode.com/todos12/1", undefined, 3);


//     function MyClass(name, age)
//     {

//         this.name = name;
//         this.age = age;
//     }
//     MyClass.prototype.myFunc = function ()
//     {
//         console.log('hi', this.name);
//     }
//     const newObj1 = new MyClass('raj', 20);
//     const newObj2 = myNew(MyClass, 'raj', 20);
//     // Object.create()
//     // function myNew(constructorFn, ...params) {
        
//     //     // constructorFn.func = this;
//     //     // constructorFn.func(...params)
//     //     // 
//         const newObj = Object.create(constructorFn.prototype);
//     //     // get all prototype constructorFn  and append prototype to newObj
//     //     // newObj  prototype
//     //     constructorFn.call(newObj,...params);
//     //     return newObj;
//     // }
//         // console.log(newObj1, newObj2)
//         // newObj1.myFunc();
//         // newObj1 instanceof MyClass
 

//         return (
//             <div>CodingTest</div>
//         )
//     }

//     export default CodingTest