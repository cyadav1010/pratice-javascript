import React, { useState } from 'react';

const ProgressiveImage = ({ lowQualitySrc, highQualitySrc, alt }) => {
  const [highResLoaded, setHighResLoaded] = useState(false);

  return (
    <div style={{ position: 'relative', width: '300px', height: '200px' }}>
      {/* Low-quality image (always visible) */}
          {!highResLoaded && <img
              src={lowQualitySrc}
              alt={alt}
              style={{
                  //   position: 'absolute',
                  width: '100%',
                  height: '100%',
                  objectFit: 'cover',
                  filter: 'blur(10px)', // Blur the placeholder for better UX
                  transition: 'opacity 0.5s ease-out',
                  opacity: highResLoaded ? 0 : 1,
              }}
          />}

      {/* High-quality image (fades in once loaded) */}
      <img
        src={highQualitySrc}
        alt={alt}
        onLoad={() => setHighResLoaded(true)}
        style={{
        //   position: 'absolute',
          width: '100%',
          height: '100%',
          objectFit: 'cover',
          transition: 'opacity 0.5s ease-in',
          opacity: highResLoaded ? 1 : 0,
        }}
      />
    </div>
  );
};

export default ProgressiveImage;
