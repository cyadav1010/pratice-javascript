import React, { useState, useEffect, useRef } from 'react'
import suggestionData from './data'
import './style.css';
const suggestionData = ["Apple", "App", "Banana", "Cat", "Dog"]
const AutoComplete = () => {
    const [data, setData] = useState(suggestionData);
    const [input, setInput] = useState("");
    const [suggestions, setSuggestions] = useState([]);
    const timerId = useRef(null);
    const debounceTimer = useRef(null)
    // debounce 
    const handleChangeInput = (ele) => {
        let value = ele.target.value;
        setInput(value);

    }
    function getNewSuggestion(value) {
        if (input) {
            let newSuggestions = data?.filter((item) => item.toLowerCase().includes(value?.toLowerCase()));
            setSuggestions(newSuggestions);
            return newSuggestions;
        } else {
            setSuggestions([]);
            return [];
        }
    }
    // debouner 

    // const debounce = (fn, delay) => {
    //     // const debounceTimer
    //     return (...args) => {
    //         if (!debounceTimer.current) {
    //             debounceTimer.current = setTimeout(() => {
    //                 fn(args);
    //             }, delay);
    //         }
    //         clearTimeout(debounceTimer.current);
    //     }
    // }
    
    useEffect(() => {
        timerId.current = setTimeout(() => {
            getNewSuggestion(input);
        }, 1000);
        return () => clearTimeout(timerId.current)
    }, [input]);

    const onKeyEnter = (event) => {
        if (event.key == "Enter") {
            if (suggestions.length == 0) {
                setData((prev) => [...prev, input]);
            }
        }
    }
    return (
        <div>
            <div>
                <input
                    value={input}
                    onChange={(ele) => handleChangeInput(ele)}
                    onKeyDown={onKeyEnter}
                />
            </div>
            {input && suggestions?.length > 0 && <div className='suggestionList' >
                {suggestions?.map((item) => {
                    return (<div className='items'>{item}</div>)
                })}
            </div>}
        </div>
    )
}

export default AutoComplete