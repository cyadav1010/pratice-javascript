// <!DOCTYPE html>
// <html lang="en">
// <head>
//     <meta charset="UTF-8">
//     <meta name="viewport" content="width=device-width, initial-scale=1.0">
//     <title>Lazy Loading Images</title>
//     <style>
//         img {
//             width: 300px;
//             height: 200px;
//             object-fit: cover;
//             display: block;
//             margin: 20px 0;
//             background-color: #f0f0f0; /* Placeholder effect */
//         }
//     </style>
// </head>
// <body>

//     <!-- Placeholder images -->
//     <img data-src="https://via.placeholder.com/600x400?text=Image+1" alt="Lazy Image 1" />
//     <img data-src="https://via.placeholder.com/600x400?text=Image+2" alt="Lazy Image 2" />
//     <img data-src="https://via.placeholder.com/600x400?text=Image+3" alt="Lazy Image 3" />

//     <script>
//         // Step 1: Select all images with data-src attribute
//         const lazyImages = document.querySelectorAll('img[data-src]');

//         // Step 2: Create the IntersectionObserver
//         const imageObserver = new IntersectionObserver((entries, observer) => {
//             entries.forEach(entry => {
//                 if (entry.isIntersecting) {
//                     const img = entry.target;
//                     img.src = img.getAttribute('data-src'); // Load the image
//                     img.removeAttribute('data-src'); // Clean up the attribute
//                     observer.unobserve(img); // Stop observing after loading
//                 }
//             });
//         });

//         // Step 3: Observe each image
//         lazyImages.forEach(image => {
//             imageObserver.observe(image);
//         });
//     </script>

// </body>
// </html>


const services = [
    getUserProfile(),
    getUserPosts(),
    getUserFriends()
];

const promise = Promise.allSettled(services);
           
promise.then(results => {
    results.forEach((result, i) => {
        if (result.status === 'fulfilled') {
            console.log(`Data from service ${i+1}:`, result.value);
        } else {
            console.error(`Error from service ${i+1}:`, result.reason);
        }
    });
});