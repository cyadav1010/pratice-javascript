import React, { useState, useEffect, useRef } from 'react'

export const UserOffline = () => {
    // const [isOffline, setIsOffline] = useState(false);
    const isOfflineRef = useRef(false)
    const currentUlr = window?.location;
    console.log("currentUlr", currentUlr);
    const offline = true;
    useEffect(() => {
        console.log("calling");
        if (true) {
            // setIsOffline(!isOffline);
            // let prevValue = isOfflineRef?.current;
            isOfflineRef.current = !isOfflineRef.current
            window.location = currentUlr;
        }
    }, [])
    return { isOfflineRef };
}
