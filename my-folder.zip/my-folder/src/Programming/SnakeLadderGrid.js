import React, { useState } from "react";
import "./SnakeLadderGrid.css";

const ladders = [
  { start: 3, end: 22 },
  { start: 5, end: 8 },
  { start: 11, end: 26 }
];

function SnakeLadderGrid() {
  const boardSize = 30;
  const gridCols = 5;

  // Calculate tile coordinates (assuming each tile is 60x60px)
  const getTileCoordinates = (tileNumber) => {
    const row = Math.floor((tileNumber - 1) / gridCols);
    const col = (tileNumber - 1) % gridCols;
    return { x: col * 60 + 30, y: row * 60 + 30 }; // Center of the tile
  };

  return (
    <div className="board-container">
      <div className="grid">
        {[...Array(boardSize)].map((_, i) => (
          <div key={i} className="tile">
            {i + 1}
          </div>
        ))}
      </div>

      <svg className="overlay" width="100%" height="100%">
        {ladders.map((ladder, index) => {
          const start = getTileCoordinates(ladder.start);
          const end = getTileCoordinates(ladder.end);
          return (
            <line
              key={index}
              x1={start.x}
              y1={start.y}
              x2={end.x}
              y2={end.y}
              stroke="brown"
              strokeWidth="4"
              markerEnd="url(#arrow)"
            />
          );
        })}
        {/* Arrow Marker */}
        {/* <defs>
          <marker
            id="arrow"
            markerWidth="10"
            markerHeight="10"
            refX="5"
            refY="5"
            orient="auto-start-reverse"
          >
            <path d="M0,0 L10,5 L0,10 Z" fill="brown" />
          </marker>
        </defs> */}
      </svg>
    </div>
  );
}

export default SnakeLadderGrid;
