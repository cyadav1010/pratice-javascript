class RateLimit { 
    constructor(maxRequest,windowSize) {
        this.TIME_WINDOW = windowSize;
        this.MAX_REQUESTS = maxRequest;
        this.clientRequests = new Map();
    }
    isClientAllow(clientId) {
        const currentTime = Date.now();
        if (!this.clientRequests.has(clientId)) {
            this.clientRequests.set(clientId, []);
        }
        let requestTimeStamp = this.clientRequests.get(clientId);
        // remove all timeStamp if (requestTimeStamp[0]-currentTime>this.TIME_WINDOW) keep removing first element from array
        
        while (requestTimeStamp.length > 0 && currentTime-requestTimeStamp[0] > this.TIME_WINDOW ) {
            requestTimeStamp.shift();
        }
        if (requestTimeStamp.length >= this.MAX_REQUESTS) {
            return false;
        }
        requestTimeStamp.push(currentTime);
        return true;
     }
}

const rateLimitObj = new RateLimit(10, 1000);
const clientID = "client_1";

for (let i = 0; i < 105; i++) {
    if (rateLimitObj.isClientAllow(clientID)) {
        console.log(`Request ${i + 1}: Allowed ✅`);
    } else {
        console.log(`Request ${i + 1}: Denied ❌`);
    }
}