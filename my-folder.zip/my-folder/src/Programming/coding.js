class MinPriorityQueue {
    constructor() {
        this.queue = [];
    }
    enqueue(element, priority) {
        this.queue.push({ element, priority });
        this.queue.sort((a, b) => a.priority - b.priority);
    }
    dequeue() {
        return this.queue.shift();
    }
    font() {
        return this.queue[0];
    }
    size() {
        return this.queue.length;
    }

}

const queue = new MinPriorityQueue();
queue.enqueue('task1', 5);
queue.enqueue('task2', 2);
queue.enqueue('task3', 3);

const frontElement = queue.front();
console.log(frontElement.priority); // Output: 2
console.log(frontElement.element);  // Output: 'task2'
const CodingTest = () => {
    let arr = [
        ["A", "@#", "3", "Q", "B", "17"],
        ["Z", "1", "GO", "3", "A", "@#", "1", "A", "A"],
        ["T", "@#", "1", "A", "8"],
        ["100", "150", "@#", "300", "500", "1", "A", "SO"]
    ];
    let arr1 = [
        ["A", "@#", "A", "3", "Q", "B", "17"],
        ["Z", "1", "GO", "3", "A", "@#", "A", "1"],
        ["T", "@#", "1", "A", "A", "8"],
        ["100", "150", "@#", "300", "500", "1", "A", "SO", "A"],
    ];

    // if (!mapObj.has(key)) {
    //     mapObj.set(key, 1); 
    // }
    // else 
    // {
    //     let value = mapObj.get(key);
    //     if (value<i+1) {

    //     }
    //     }
    function getIntersection(arr) {
        let mapObj = new Map();
        let arrLen = arr.length;
        for (let i = 0; i < arrLen; i++) {
            let tempMap = new Map();
            for (let j = 0; j < arr[i].length; j++) {
                let key = arr[i][j];
                if (!tempMap.has(key)) {
                    tempMap.set(key, 1);
                }
            }
            for (const [key, value] of tempMap) {
                let value = 0;
                if (mapObj.has(key)) {
                    value = mapObj.get(key);
                }
                mapObj.set(key, value + 1);
            }
        }
        let result = [];
        for (const [key, value] of mapObj) {
            if (mapObj.get(key) == arrLen) {
                result.push(key);
            }
        }
        console.log("mapObj", mapObj);
        console.log("result", result);
    };
    getIntersection(arr1);

    // console.log("tempMap", tempMap);
    // let allKeys = tempMap.keys();
    // console.log("allKeys", allKeys);
    // for (let k = 0; k < allKeys.length; k++) {
    //     let key = allKeys[k];
    //     console.log("key===>>", key);
    //     let value = 0;
    //     if (mapObj.has(key)) {
    //         value = mapObj.get(key);
    //     }
    //     mapObj.set(key, value + 1);

    // }
    // return (
    //     <div>CodingTest</div>
    // )
}

// export default CodingTest



// Dependent Tasks
// Problem Statement
// Consider the following object and note its structure. 
// Each key in the object tasks represents a task.
// A task has a job function which accepts a "finish" callback.
// A task is started by invoking its job function, and it's considered completed 
// when the finish callback is executed.Additionally, a task may have a dependencies array,
//  with its elements as names of other tasks - indicating that the task requires those dependencies to be 
//  completed before it can be started.

const tasks = {
    'a': {
        job: function (finish) {
            setTimeout(function () {
                console.log('a done');
                finish();
            }, 3000);
        }
    },
    'b': {
        job: function (finish) {
            setTimeout(function () {
                console.log('b done');
                finish();
            }, 2000);
        }
    },
    'c': {
        job: function (finish) {
            setTimeout(function () {
                console.log('c done');
                finish();
            }, 0);
        },
        dependencies: ['a', 'b']
    },
    'd': {
        job: function (finish) {
            setTimeout(function () {
                console.log('d done');
                finish();
            }, 1000);
        },
        dependencies: []
    },
    'e': {
        job: function (finish) {
            setTimeout(function () {
                console.log('e done');
                finish();
            }, 0);
        },
        dependencies: ['c', 'b']
    }
};
function runTasks() {
    let keys = Object.keys(tasks);
    console.log("keys", keys);
    const taskKeys = Object.keys(tasks);
    let inDegree = {};
    let inDegMap = new Map();
    let graph = {};
    let queue = [];

    taskKeys.forEach((key) => {
        graph[key] = [];
        inDegree[key] = 0;
    });
    taskKeys.forEach((key) => {
        const dependencies = tasks[key].dependencies || [];
        dependencies.forEach((dependency) => {
            graph[dependency].push(key);
            inDegree[key]+= 1;
        })
    })
    taskKeys.forEach((key) => {
        if (inDegree[key] === 0) {
            queue.push(key);   
        }
    })
    let completedTasks = 0;
    function processTask(taskKey) {
        let { job } = tasks[taskKey];
        job(() => {
            console.log(`${taskKey} completed`);
            completedTasks++;
            let dependentTask = graph[taskKey];
            dependentTask.forEach((ele) => {
                inDegree[ele]--;
                if (inDegree[ele] === 0) {
                    queue.push(ele);
                }
            })
            if (completedTasks === taskKeys.length) {
                 console.log('all completed completed');
            }
            else {
                if (queue.length > 0) {
                    let currQu = queue.shift();
                    processTask(currQu);
                }
            }
        })
    }
    while (queue.length > 0) {
        let key = queue.shift();
        processTask(key);
    }
}
// Write a function that accepts such an object, and completes all the tasks by first completing ALL of their dependencies FIRST, and finally prints "all completed" after the last task has completed.
// Signature
// function runTasks() { /* implement */ }

// Completes all tasks in order (a task's dependencies first, then the task itself).
// Finally, prints 'all completed' to the console when the last task is completed.
// The function signature for runTasks() can be expanded as needed (feel free to add additional parameters).




const obj = {
    anotherProp:"chandan",
    anotherObj: {
        anotherAnothterObj: {
            a: 6
        }
    }
}
const obj1 = {
    ...obj,
    anotherObj: {
        ...obj.anotherObj,
        anotherAnothterObj: {
            ...obj.anotherAnothterObj,
            a:7
        }
    }
}


// Connect with Bittu Kumar
// Guess the output of this simple question and explain the reason. 
// This three question will completely clear your concept related to 
// let,var, block scoped, hoisting etc ...

// Copy code from here and try !!
// Example 1
var rate= 10;
function getRate(){
 console.log("rate",rate)   // output ??
 if(rate== undefined){
 var rate= 6;
 return rate;
 }
 else{
 return 10;
 } 
}
console.log("function call ",getRate());  // output ??


// Example 2 (replace var with let )
let rate= 10;
function getRate(){
 console.log("rate",rate) // output ??
 if(rate== undefined){
 let rate= 6;
 return rate;
 }
 else{
 return 10;
 } 
}
console.log("function call ",getRate());  // output ??


// Example 3
var rate= 10;
function getRate(){
 console.log("rate",rate)  // output ??
 return rate;
}
console.log("function call ", getRate());  // output ??





//     function getAns(str,str2) {
//         let res = str + str;
//         if (res.includes(str2)) {
//             return true;
//         }
//         return false;
//     }
//     console.log(getAns("hello", "lohe"));

//  const obj = {
//   name: 'Jhon',
//   getName(){
//     console.log(this.name);
//   },
//   getName2: ()=>{
//   console.log(this.name);
// }
// }
//     obj.getName(); // Jhon
//     obj.getName2();// undefined




let tempArray = [1, 2, 3, 4, 5];


tempArray.push(6);//add element to last 
tempArray.pop() // remove last element in array 
tempArray.shift();// remove first element in array 
tempArray.unshift(1); // add element at first of array 
tempArray.slice(1, 3);
tempArray.splice(1, 2, 3);// splice(start, deleteCount, items):

// const lazyComponent=React.lazy(()=>import('./LazyComponent'));

{/* <Suspense fallback={<div>Loading...</div>}>
        <LazyComponent />
      </Suspense> */}