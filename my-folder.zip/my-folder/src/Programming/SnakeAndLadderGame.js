import React, { useState } from "react";
import "./SnakeLadder.css";  // Simple CSS for the game
import ladderIcon from './ladder.svg'
const snakesAndLadders = {
  3: 22,   // Ladder from 3 to 22
  5: 8,    // Ladder from 5 to 8
  11: 26,  // Ladder from 11 to 26
  17: 4,   // Snake from 17 to 4
  19: 7,   // Snake from 19 to 7
  27: 1    // Snake from 27 to 1
};
const ladderMapping = {
   3: 22,   // Ladder from 3 to 22
  5: 8,    // Ladder from 5 to 8
  11: 26,  // Ladder from 11 to 26
}
const snakeMapping = {
   17: 4,   // Snake from 17 to 4
  19: 7,   // Snake from 19 to 7
  27: 1    // Snake from 27 to 1
}

const laddersMapping = [
  { start: 3, end: 22 },
  { start: 5, end: 8 },
  {start: 11, end : 26},
]
const generateDiceRoll = () => Math.floor(Math.random() * 6) + 1;

function SnakeAndLadderGame() {
  const [playerPositions, setPlayerPositions] = useState([0, 0]); // Player 1 and 2
  const [currentPlayer, setCurrentPlayer] = useState(0); // Player turn
  const [winner, setWinner] = useState(null);
  const boardSize = 30;  // Game with 30 tiles for simplicity
  const gridsCols = 5;
  const rollDice = () => {
    if (winner) return;

    const diceRoll = generateDiceRoll();
    let newPosition = playerPositions[currentPlayer] + diceRoll;

    if (newPosition >= boardSize) {
      setWinner(`Player ${currentPlayer + 1} wins!`);
      return;
    }

    // Check for snakes or ladders
    newPosition = snakesAndLadders[newPosition] || newPosition;

    // Update player position
    const updatedPositions = [...playerPositions];
    updatedPositions[currentPlayer] = newPosition;
    setPlayerPositions(updatedPositions);

    // Switch player
    setCurrentPlayer((currentPlayer + 1) % 2);
  };
  const getIsLadderPresent = (index) => {
    if (ladderMapping[index]) {
      return true;
    } else {
      return false;
    }
  }
  const getIsSankePresent = (index) => {
    if (snakeMapping[index]) {
      return true;
    } else {
      return false;
    }
  }

  const getCoordinates = (gridNumber) => {
    const row = Math.floor(gridNumber / gridsCols);
    const col = (gridNumber) % gridsCols;
    console.log("getCoordinates",gridNumber,"====>",{x: col * 60 + 30, y: row * 60+30})
    return { x: col * 60 + 30, y: row * 60+30 }; // get x and y axis
  }
  return (
    <div className="game-container">
      {/* <h1>Snake and Ladder Game</h1> */}
      {/* {winner ? <h2 className="winner">{winner}</h2> : <h2>Player {currentPlayer + 1}'s Turn</h2>} */}

      <div className="board">
        {[...Array(boardSize)].map((_, i) => (
          <div key={i} className="tile">
            <div className="tile-number">
              {i + 1}
             
            </div>
            <div>
              {getCoordinates(i+1) ? "": ""}
              {getIsLadderPresent(i + 1) ? <span><img width="20px" height="20px" src={ladderIcon }></img></span> : ""}
              {getIsSankePresent(i+1)? "S":""}
            </div>
            {playerPositions[0] === i && <div className="player player1">P1</div>}
            {playerPositions[1] === i && <div className="player player2">P2</div>}
          </div>
        ))}
      </div>
      <div>
      <svg className="drawLine">
        {laddersMapping.map((ladder, index) => {
          const start = getCoordinates(ladder.start);
          const end = getCoordinates(ladder.end);
          return (
            <line
              key={index}
              x1={start.x}
              y1={start.y}
              x2={end.x}
              y2={end.y}
              stroke="red"
              strokeWidth="4"
            />
          )
        })}
      </svg>
        </div>
      {/* <button onClick={rollDice} className="dice-button">Roll Dice</button> */}
      {/* <p>Player 1 Position: {playerPositions[0]}</p> */}
      {/* <p>Player 2 Position: {playerPositions[1]}</p> */}
    </div>
  );
}

export default SnakeAndLadderGame;










// import React, { useState } from "react";
// import { Card, CardContent } from "@/components/ui/card"; // Using Shadcn components

// // Board Configuration
// const snakesAndLadders = {
//   3: 22,   // Ladder from 3 to 22
//   5: 8,    // Ladder from 5 to 8
//   11: 26,  // Ladder from 11 to 26
//   17: 4,   // Snake from 17 to 4
//   19: 7,   // Snake from 19 to 7
//   27: 1    // Snake from 27 to 1
// };

// const generateDiceRoll = () => Math.floor(Math.random() * 6) + 1;

// function SnakeAndLadderGame() {
//   const [playerPositions, setPlayerPositions] = useState([0, 0]); // Player 1 and 2 positions
//   const [currentPlayer, setCurrentPlayer] = useState(0); // 0 for Player 1, 1 for Player 2
//   const [winner, setWinner] = useState(null);
  
//   const rollDice = () => {
//     if (winner) return;

//     const diceRoll = generateDiceRoll();
//     let newPosition = playerPositions[currentPlayer] + diceRoll;

//     if (newPosition >= 30) {  // Assuming a simple 30-tile game for demo
//       setWinner(`Player ${currentPlayer + 1} wins!`);
//       return;
//     }

//     // Check for snake or ladder
//     newPosition = snakesAndLadders[newPosition] || newPosition;

//     // Update player position
//     const updatedPositions = [...playerPositions];
//     updatedPositions[currentPlayer] = newPosition;
//     setPlayerPositions(updatedPositions);

//     // Switch player
//     setCurrentPlayer((currentPlayer + 1) % 2);
//   };

//   return (
//     <div className="p-4 max-w-md mx-auto text-center">
//       <h1 className="text-xl font-bold">Snake and Ladder Game</h1>
//       {winner ? (
//         <h2 className="text-green-600">{winner}</h2>
//       ) : (
//         <h2 className="text-blue-600">Player {currentPlayer + 1}'s Turn</h2>
//       )}

//       <div className="mt-4 grid grid-cols-5 gap-2">
//         {[...Array(30)].map((_, i) => (
//           <Card key={i} className="p-4">
//             <CardContent>{i + 1}</CardContent>
//           </Card>
//         ))}
//       </div>

//       <div className="mt-6">
//         <button
//           onClick={rollDice}
//           className="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-700"
//         >
//           Roll Dice
//         </button>
//         <p className="mt-2">Player 1: {playerPositions[0]}</p>
//         <p>Player 2: {playerPositions[1]}</p>
//       </div>
//     </div>
//   );
// }

// export default SnakeAndLadderGame;
