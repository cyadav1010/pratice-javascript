import React,{useEffect,useState,useRef} from 'react'
import './progress.css';
const CustomProgressBar = () => {

    const [width, setWidth] = useState(0);
    let timerId = useRef(null);
    useEffect(() => {
        timerId.current = setInterval(() => {
            setWidth((prev) => {
                if (prev >= 100) {
                    clearInterval(timerId.current);
                    return prev;
                } else {
                    return prev + 5;
                }
            })
        }, 30);
        return () => {
            clearInterval(timerId.current);
        }
    }, []);

  return (
      <div>
          <div className='customProgressWrapper'>
              <div
                  style={{ transform: `translatex(${width - 100}%)` }}
                //   style={{ width: `${width}%` }}
                  className='progressBar'
                //   className={`progressBar ${width > 0 ? 'start' : ''}`}
              >
              </div>
          </div>
    </div>
  )
}

export default CustomProgressBar