import React, { useState,useEffect } from 'react'

const TaskPopup = ({ task, isEditable, handleCancleTask = () => { }, handleSaveTasks = () => { },handleEditExitTask=()=>{} }) => {
    console.log("task===>", task);
    const [editTask, setEditTask] = useState(task);
    useEffect(() => {
        setEditTask(task);
    }, [task])
    const handleOnChange = (key, e) => {
        let value = e.target.value;
        setEditTask((prevTask) => ({ ...prevTask, [key]: value }));
    }
    const handleSaveTask = () => {

        if (isEditable) {
            handleEditExitTask(editTask);
        } else {
            let obj = { ...editTask };
            obj['taskId'] = Date.now();
            handleSaveTasks(obj);
        }
    }
    return (
        <div>

            <label> Desc</label>
            <input placeholder='' value={editTask?.Desc} onChange={(e) => handleOnChange('Desc', e)}></input>
            <label> Assignee</label>
            <input placeholder='' value={editTask?.Assignee} onChange={(e) => handleOnChange('Assignee', e)}></input>
            <label> DueDate</label>
            <input placeholder='' value={editTask?.DueDate} onChange={(e) => handleOnChange('DueDate', e)}></input>
            
            <label> State</label>
            <input placeholder='' value={editTask?.State} onChange={(e) => handleOnChange('State', e)}></input>
            <button onClick={() => handleSaveTask()}>Save Task</button>
            <button onClick={() => handleCancleTask()}>Cancle Task</button>
        </div>
    )
}

export default TaskPopup