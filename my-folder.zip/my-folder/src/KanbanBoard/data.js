const data = [
    {   taskId:12,
        desc:"gst filing flow",
        State: "planned",
        DueDate: "12/10/2024",
        Assignee:"james"
    },
    {   taskId:13,
        Desc:"metric dasboard",
        State: "started",
        DueDate: "12/10/2024",
        Assignee:"chandan"
    },
    {   taskId:14,
        Desc:"error dasboard",
        State: "started",
        DueDate: "12/10/2024",
        Assignee:"chandan"
    },
    {   taskId:15,
        Desc:"advanced return flow",
        State: "started",
        DueDate: "12/10/2024",
        Assignee:"chandan"
    },
    {   taskId:16,
        Desc:"analytics dasboard",
        State: "done",
        DueDate: "12/10/2024",
        Assignee:"jenny"
    }
]
export default data;