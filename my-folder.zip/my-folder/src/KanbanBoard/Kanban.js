import React, { useState, useEffect } from 'react'
import data from './data';
import './style.css';
import TaskPopup from './TaskPop';
const Kanban = () => {
    const [kabanaData, setKabanaData] = useState(data);
    const [status, setStatus] = useState(["planned", "started", "done"]);
    const [addEdit, setAddEdit] = useState(false);
    let initalObj = {
        Desc: "",
        State: "",
        DueDate: "",
        Assignee: ""
    };
    const [editObj, setEditObj] = useState(initalObj);
    const [newTask, setNewTask] = useState(initalObj);
    let editAddObj = {
        edit: false,
        add: false,
    };
    const [editAdded, setEditAdded] = useState(editAddObj);
    const [isEditable, setIsEditable] = useState(false);
    const [isnewTask, setisnewTask] = useState(false);
    const handleAddTask = (state) => {
        setNewTask((prev) => {
            let prevObj = { ...prev };
            prevObj['State'] = state;
            return prevObj;
        })
        setisnewTask(true);
    }
    // const handleEditAddedTask = (key) => {
    //     setEditAdded((prev)=>({...prev,[key]:true}))
    // }
    const handleEditTask = (task) => {
        console.log("editTask", task);
        setEditObj(task);
        setIsEditable(true);
    };
    const handleSaveTask = () => {
        let tempData = [...kabanaData];
        tempData.push(editObj);
        setKabanaData(tempData);
        setEditObj(initalObj);
    };

    const handleOnChange = (key, e) => {
        let value = e.target.value;
        // console.log("value", "key", key, value);
        // setEditObj((prev)=>({...prev,[key]:value}))
        setEditObj((prev) => {
            let prevObj = { ...prev };
            prevObj[key] = value;
            return prevObj;
        })
    }
    useEffect(() => {
        console.log("editObj", editObj);
    }, [editObj])
    const editExtingTask = (task) => {

    }
    const handleSaveTasks = (task) => {
        console.log("task=====>>>", task)
        let tempData = [...kabanaData];
        tempData.push(task);
        setKabanaData(tempData);
        resetAll();
    }
    const handleEditExitTask = (task) => {
        let tempData = [...kabanaData];
        let resData = tempData.filter((data) => data?.taskId != task?.taskId);
        console.log("resData", resData);
        resData.push(task);
        setKabanaData(resData);
    }
    const resetAll = () => {
        setEditObj(initalObj);
        setNewTask(initalObj);
        setIsEditable(false);
        setisnewTask(false);
    }
    const handleCancleTask = () => {
        resetAll();
    };
    return (
        <>
            <div className='kibanaBoardWrapper'>{status.map((state) => {
                let resData = kabanaData?.filter(data => data?.State == state);
                return (
                    <div className='kibanaBoard'>
                        <div>{state}</div>
                        {
                            resData?.map((ele, index) => {
                                return (
                                    <>
                                        <div className='boarditems' onClick={() => handleEditTask(ele)}>
                                            <div>{ele.Desc}</div>
                                            <div>{ele.DueDate}</div>
                                            <div>{ele.Assignee}</div>
                                        </div>
                                        <div>
                                            {resData?.length - 1 == index && <button onClick={() => handleAddTask(state)}>add another task</button>}
                                        </div>
                                    </>
                                )
                            })}
                    </div>
                )
            })}</div>
            {(isEditable || isnewTask) && <TaskPopup task={isEditable ? editObj : newTask} handleCancleTask={handleCancleTask} handleSaveTasks={handleSaveTasks} isEditable={isEditable} handleEditExitTask={handleEditExitTask} />}
        </>
    )
}

export default Kanban;