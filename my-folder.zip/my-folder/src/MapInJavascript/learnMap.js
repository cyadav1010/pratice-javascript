const map1 = new Map();
map1.set('0', 'foo');
map1.set(1, 'bar');

// Using the spread operator
const keysArraySpread = [...map1.keys()];
console.log(keysArraySpread); // Output: ['0', 1]

// Using Array.from()
const keysArrayFrom = Array.from(map1.keys());
console.log(keysArrayFrom); // Output: ['0', 1]


// const valuesArray = Array.from(iterator1);
// console.log(valuesArray); // Output: ['foo', 'bar']

// // Or using the spread operator:
// const valuesArraySpread = [...map1.values()];
// console.log(valuesArraySpread); // Output: ['foo', 'bar']