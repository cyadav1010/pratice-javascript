const formConfig = [
  {
    step: "Profile",
    fields: [
      { name: "name", type: "text", label: "Name", required: true },
      { name: "email", type: "email", label: "Email", required: true, validation: (value) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value) || "Invalid email format" },
      { name: "age", type: "number", label: "Age", required: true, validation: (value) => !isNaN(value) || "Age must be numeric" },
      { name: "address1", type: "text", label: "Address Line 1", required: false },
      { name: "address2", type: "text", label: "Address Line 2", required: false },
    ],
  },
  {
    step: "Interest",
    fields: [
      { name: "hobbies", type: "select", label: "Hobbies", options: ["Football", "Cricket", "Other"], required: true },
      { name: "favoriteGenre", type: "radio", label: "Favorite Genre", options: ["Fiction", "Non-Fiction", "Mystery", "Fantasy"], required: true },
    ],
  },
  {
    step: "Settings",
    fields: [
      { name: "notifications", type: "checkbox", label: "Notifications (Optional)", required: false },
      { name: "privacy", type: "checkbox", label: "Privacy Level (Required)", required: true },
    ],
  },
];
export default formConfig;