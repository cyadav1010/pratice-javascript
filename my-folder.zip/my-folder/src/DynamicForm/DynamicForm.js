import React, { useState,useEffect } from "react";

const DynamicForm = ({ config }) => {
  const [stepIndex, setStepIndex] = useState(0);
  const [formData, setFormData] = useState({});
  const [errors, setErrors] = useState({});

  const currentStep = config[stepIndex];

  const handleChange = (e) => {
      const { name, value, type, checked } = e.target;
      console.log("name, value, type, checked", name, value, type, checked);
    setFormData({
      ...formData,
      [name]: type === "checkbox" ? checked : value,
    });
  };
  useEffect(() => {
      console.log("formData", formData);
  }, [formData])
  const validateStep = () => {
    const stepErrors = {};
    currentStep.fields.forEach((field) => {
      if (field.required && !formData[field.name]) {
        stepErrors[field.name] = `${field.label} is required`;
      }
      if (field.validation && formData[field.name]) {
        const validationError = field.validation(formData[field.name]);
        if (validationError !== true) {
          stepErrors[field.name] = validationError;
        }
      }
    });
    setErrors(stepErrors);
    return Object.keys(stepErrors).length === 0;
  };

  const handleNext = () => {
    if (validateStep()) {
      setStepIndex(stepIndex + 1);
    }
  };

  const handleBack = () => {
    setStepIndex(stepIndex - 1);
  };

  const handleSubmit = () => {
    if (validateStep()) {
      console.log("Form submitted:", formData);
      alert("Form submitted successfully");
    }
  };

  return (
    <div style={{ padding: "20px", maxWidth: "600px", margin: "auto" }}>
      <h2>{currentStep.step}</h2>
          {currentStep.fields.map((field) => {
              return (
                  <div key={field.name} style={{ marginBottom: "10px" }}>
                      <label>
                          {field.label}
                          {field.type === "text" || field.type === "email" || field.type === "number" ? (
                              <input
                                  type={field.type}
                                  name={field.name}
                                  value={formData[field.name] || ""}
                                  onChange={handleChange}
                              />
                          ) : field.type === "select" ? (
                              <select name={field.name} value={formData[field.name] || ""} onChange={handleChange}>
                                  <option value="">Select</option>
                                  {field.options.map((option) => (
                                      <option key={option} value={option}>
                                          {option}
                                      </option>
                                  ))}
                              </select>
                          ) : field.type === "radio" ? (
                              field.options.map((option) => (
                                  <label key={option} style={{ marginLeft: "10px" }}>
                                      <input
                                          type="radio"
                                          name={field.name}
                                          value={option}
                                          checked={formData[field.name] === option}
                                          onChange={handleChange}
                                      />
                                      {option}
                                  </label>
                              ))
                          ) : field.type === "checkbox" ? (
                              <input
                                  type="checkbox"
                                  name={field.name}
                                  checked={!!formData[field.name]}
                                  onChange={handleChange}
                              />
                          ) : null}
                      </label>
                      {errors[field.name] && <p style={{ color: "red" }}>{errors[field.name]}</p>}
                  </div>)
          })}
      <div style={{ marginTop: "20px" }}>
        <button disabled={stepIndex === 0} onClick={handleBack}>
          Back
        </button>
        {stepIndex < config.length - 1 ? (
          <button onClick={handleNext} style={{ marginLeft: "10px" }}>
            Next
          </button>
        ) : (
          <button onClick={handleSubmit} style={{ marginLeft: "10px" }}>
            Submit
          </button>
        )}
      </div>
    </div>
  );
};

export default DynamicForm;
