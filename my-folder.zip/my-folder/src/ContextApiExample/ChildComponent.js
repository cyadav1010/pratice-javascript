import React from 'react'
import { ParentContext } from './ParentComponent'

const ChildComponent = () => {
    const {theme, toggleTheme} = React.useContext(ParentContext);
    console.log("parentContext", ParentContext);
  return (
      <div>
          <div style={{background: theme === 'dark' ? '#333' : '#fff', color: theme === 'dark' ? '#fff' : '#333'}}>
              child component
              <button onClick={toggleTheme}>Toggle Theme</button>
          </div>
    </div>
  )
}

export default ChildComponent