import React from 'react'

const Todo = () => {
    const myContext = React.createContext();
//     The MyContext object has two important properties:
// Provider: Used to provide the context value to child components.
// Consumer: Used to consume the context value (optional in modern React).
  return (
    <div>Todo</div>
  )
}

export default Todo