import React, { useState,useReducer } from 'react'
import ChildComponent from './ChildComponent';

export const ParentContext = React.createContext();
const ParentComponent = () => {
    const [theme, setTheme] = useState('light');
    const toggleTheme = () => {
        setTheme((prevTheme) => {
            return prevTheme == "light" ? "dark" : "light";
        })
    }
      const initalValue = {
        count: 0
    };
    const reducer = (state, action) => {
        switch (action.type) {
            case "INCREMENT":
                return { ...state, count: state.count + 1 };
        }
    }
    const [state, dispatch] = useReducer(reducer, initalValue)
    // return (
    //     <div>
    //         <h1>Count: {state.count}</h1>
    //         <button onClick={() => dispatch({ type: "INCREMENT" })}>Increment</button>
    //         <button onClick={() => dispatch({ type: "DECREMENT" })}>Decrement</button>
    //         <button onClick={() => dispatch({ type: "RESET" })}>Reset</button>
    //     </div>
    // )
    return (
        <div>
             <div>
            <h1>Count: {state.count}</h1>
            <button onClick={() => dispatch({ type: "INCREMENT" })}>Increment</button>
            <button onClick={() => dispatch({ type: "DECREMENT" })}>Decrement</button>
            <button onClick={() => dispatch({ type: "RESET" })}>Reset</button>
        </div>
            <ParentContext.Provider value={{ theme, toggleTheme }}>
                <ChildComponent />
            </ParentContext.Provider>
        </div>
    )
}

export default ParentComponent