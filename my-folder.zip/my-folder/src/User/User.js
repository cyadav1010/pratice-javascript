import React,{useState} from 'react'
import userDetailList from '../data'
import EditUser from './EditUser';
import ViewUser from './ViewUser';

const User = () => {
    const [users, setUsers] = useState(userDetailList);
    const [editUser, setEditUser] = useState({});
    const [isEdit, setIsEdit] = useState(false);
    // const columns = [];
    const handleEditUserInfo = (user) => {
        setEditUser(user);
        setIsEdit(true);
    }
    const handleSubmitUser = (dep,mobile) => {
        const tempUsers = [...users];
        const resUser = tempUsers.filter((user) => user.id != editUser.id);
        console.log("resUser", resUser);
        const tempEditUser = { ...editUser };
        tempEditUser.deparment = dep;
        tempEditUser.mobile = mobile;
        resUser.push(tempEditUser);
        setUsers(resUser);
        setIsEdit(false);
        setEditUser({})
    }
  return (
      <div>
          {!isEdit && users?.map((user) => {
              return (<ViewUser user={user} handleEditUserInfo={ handleEditUserInfo} />)
          })}
          {isEdit && <EditUser user={editUser} handleSubmitUser={ handleSubmitUser} />}
    </div>
  )
}

export default User