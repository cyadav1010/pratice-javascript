import React from 'react'

const ViewUser = ({ user,handleEditUserInfo=()=>{} }) => {
    return (
        <div>
            <div>
                <div> name: {user.name}</div>
                <div> emailID: {user.emailID}</div>
               <div>mobile: {user.mobile}</div>
                <div>deparment: {user.deparment}</div> 
                <button onClick={()=>handleEditUserInfo(user)}>edit info</button>
            </div>
        </div>
    )
}

export default ViewUser