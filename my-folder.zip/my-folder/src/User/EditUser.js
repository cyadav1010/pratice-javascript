import React,{useState} from 'react'

const EditUser = ({ user,handleSubmitUser=()=>{} }) => {
    const [deparment, seDeparment] = useState(user?.deparment);
    const [mobile, seMobile] = useState(user?.mobile);
    const handleOnChangeDeparment = (e) => {
        seDeparment(e.target.value)
    }
    const handleOnChangeMobile = (e) => {
        seMobile(e.target.value)
    }
    const handleSubmit = () => {
        handleSubmitUser(deparment,mobile);
    }
  return (
      <div>
          <input value={deparment} onChange={(e)=> handleOnChangeDeparment(e)} /> 
          <input value={mobile} onChange={(e) => handleOnChangeMobile(e)} /> 
          <button onClick={handleSubmit}>submit </button>
    </div>
  )
}

export default EditUser