import React from 'react'

const FeatureFlag = () => {
    const SAMPLE_FEATURES = {
        show_dialog_box: true,
        enable_new_pricing: true,
      };
      
      // returns the state of *all* features for the current user
    function  fetchAllFeatures() {
        // mocking the fetch API call
        console.log("call from BE")
        return new Promise((resolve) => {
          setTimeout(() => resolve(SAMPLE_FEATURES), 100);
        });
      }
      
      const Cache={
        featureFlags:{},
        timeStamp:null
      }
      const MAX_CACHE_TTL=100000;
      // DO NOT CHANGE THE FUNCTION NAME
      let featureInstance=null;
     async function getFeatureState(featureName, defaultValue) {
        // write your solution here
        const isCacheDataPresent = Object.keys(Cache?.featureFlags).length>0;
        const isCacheDataFresh= Date.now()-Cache?.timeStamp < MAX_CACHE_TTL;
        if(isCacheDataPresent && isCacheDataFresh ){
          console.log("called from cache")
          const value= Cache?.featureFlags?.hasOwnProperty(featureName) ? Cache?.featureFlags[featureName] :defaultValue;
         return Promise.resolve(value);
         }

         // featureInstance if in promise
         if(featureInstance){
          console.log("featureInstance present")
         return featureInstance.then((featureFlags)=>{
         return featureFlags.hasOwnProperty(featureName) ? featureFlags[featureName] : defaultValue
         })
         }

         featureInstance = fetchAllFeatures();
         return featureInstance
           .then((featureFlags) => {
             Cache.featureFlags = featureFlags;
             Cache.timeStamp = Date.now();
             featureInstance = null; // Reset instance once fulfilled
             return featureFlags.hasOwnProperty(featureName)
               ? featureFlags[featureName]
               : defaultValue;
           })
           .catch((error) => {
             console.error("Error fetching feature flags:", error);
             featureInstance = null; // Reset instance on failure
             return defaultValue;
           });



      // featureInstance = await fetchAllFeatures();
      // return featureInstance.then((featureFlags)=>{
      //   Cache.featureFlags=featureInstance;
      //   Cache.timeStamp=Date.now();
      //   if(featureInstance.hasOwnProperty(featureName)){
      //    return Promise.resolve(featureInstance[featureName]);
      //   }else{
      //   Promise.resolve(defaultValue);
      //   }
      // })
      }
      getFeatureState("show-pricing-v2")
     .then(function(isEnabled) {
      if (isEnabled) {
        console.log("show-pricing-v2 isEnabled")
      } else {
        console.log("show-pricing-v2 showOldPricing")
      }
      });

      getFeatureState("show-redesigned-dialog")
     .then(function(isEnabled) {
      if (isEnabled) {
        console.log("show-redesigned-dialog isEnabled")
      } else {
        console.log("show-redesigned-dialog showOldPricing")
      }
      });     
     
    //  setTimeout(()=>{
    //   getFeatureState("show-pricing-v2")
    //  .then(function(isEnabled) {
    //   if (isEnabled) {
    //     console.log("show-pricing-v2 isEnabled")
    //   } else {
    //     console.log("show-pricing-v2 showOldPricing")
    //   }
    //   });
    //  },300)
  return (
    <div>FeatureFlag</div>
  )
}

export default FeatureFlag