import React, { useState } from 'react'
import { items } from './mock';
import SuggestionList from './SuggestionList';
import './style.css';

const AutoComplete = () => {
    const [input, setInput] = useState(null);
    const [data, setdata] = useState(items);
    const [focusedIndex, setFocusedIndex] = useState(-1);
    const handleOnChange = (e) => {
        let { value } = e.target;
        console.log("value", value);
        setInput(value);
        filterSuggestion(value);
    };
    const filterSuggestion = (input) => {
        const resItem = items?.filter((item) => item.toLowerCase().includes(input.toLowerCase()));
        console.log("resItem", resItem);
        setdata(resItem);
    }
    const handleKeyDown = (e) => {
        console.log("e.key", e.key);
        if (e.key === "ArrowDown") {
            setFocusedIndex((prevIndex) =>
                prevIndex < data.length - 1 ? prevIndex + 1 : 0
            );
        } else if (e.key === "ArrowUp") {
            setFocusedIndex((prevIndex) =>
                prevIndex > 0 ? prevIndex - 1 : data.length - 1
            );
        }

        // if (prevIndex)
        // prevIndex> 0 ? prevIndex - 1 : data.length - 1
        // else if (e.key === "Enter" && focusedIndex >= 0) {
        //     setQuery(filteredItems[focusedIndex]); // Select the focused item
        //     setFilteredItems([]); // Clear the dropdown
        // }
    };
    // https://dummyjson.com/recipes/search
    return (
        <div className='autoSearchWrapper'>
            {/* AutoComplete */}
            <input value={input} onChange={(e) => handleOnChange(e)} onKeyDown={handleKeyDown}
                placeholder="Type to search..." />
            <SuggestionList data={data} focusedIndex={focusedIndex} />
        </div>
    )
}

export default AutoComplete