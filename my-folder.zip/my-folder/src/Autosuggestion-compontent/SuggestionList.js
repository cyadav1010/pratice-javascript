import React from 'react'

const SuggestionList = ({ data, focusedIndex }) => {
    console.log("focusedIndex", focusedIndex);
    return (
        <div className='suggestionWrapper'>
            {data?.map((ele, index) => (<div className={`suggestionElement ${focusedIndex === index ? "activeIndex" : ""}`}>{ele}</div>))}
        </div>
    )
}

export default SuggestionList