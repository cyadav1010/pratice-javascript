import { useState } from 'react';
const useFormValidation = ({ initialValues }) => {
    const [values, setValues] = useState(initialValues);
    const [errors, setErrors] = useState({});
    const [touched, setTouched] = useState({});
    const [isSubmitting, setIsSubmitting] = useState(false);
    const handleChange = (e) => {
        const { name, value } = e.target;
        setValues((prevValue)=>({...prevValue,[name]:value}))
    }
    return {
        values,
        errors,
        handleChange,
        isSubmitting,
        handleSubmit
    }  
}
export default useFormValidation;