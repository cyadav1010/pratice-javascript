import React,{useState} from 'react'

const SignupForm = () => {
    const initialValues = {
        name: "",
        emailId: "",
        passWord:""
    }
    const [initialState, setInitialState] = useState(initialValues)
    const { values,
        errors,
        handleChange,
        isSubmitting,
        handleSubmit } = useFormValidation(initialValues);
  return (
      <div>
          <label>userName</label>
          <input id="name" name="name" onChange={handleChange}/>
          <label>emailID</label>
          <input id="emailId" name='emailId' onChange={handleChange}/>
          <label>password</label>
          <input id="passWord" name="passWord" onChange={handleChange} />
          <button onClick={handleSubmit}>submit</button>
    </div>
  )
}

export default SignupForm