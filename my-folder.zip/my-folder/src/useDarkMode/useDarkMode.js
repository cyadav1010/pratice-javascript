import { useState } from 'react';

const useDarkMode = () => {
    const [isDarkMode, setIsDarkMode] = useState(() => {
        const storedPreference = localStorage.getItem("theme");
        return storedPreference === "dark" ? true : false
    });
  useEffect(() => {
      localStorage.setItem("dark-mode", JSON.stringify(isDarkMode));
     document.body.classList.toggle("dark-mode", isDarkMode);
  }, [isDarkMode])
    const toggleDarkMode = () => {
        setIsDarkMode((prevMode) => !prevMode);
    }
  return { isDarkMode, toggleDarkMode };
}

export default useDarkMode