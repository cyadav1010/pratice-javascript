import { configureStore } from '@reduxjs/toolkit';
import counterReducer from './counterSlice'; // Import the reducer (default export)
// import todoReducer from './todoSlice'

const store = configureStore({
    reducer: {
        counter: counterReducer, // Use a clear name for the reducer
    },
});

export default store;
