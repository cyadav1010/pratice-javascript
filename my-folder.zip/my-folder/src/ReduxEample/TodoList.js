import React,{useState} from 'react'
import { useDispatch, useSelector } from 'react-redux';
import { addTodo } from '../Store/actions/todoActions';

const TodoList = () => {
    const [input, setInput] = useState("");;
    const todos = useSelector((state) => state.todos);
    console.log("todos", todos);
    const dispatch = useDispatch();
    const handleOnChange = (e) => {
        const { value } = e.target;
        setInput(value);
    }
    const handleOnAdd = () => {
        dispatch(addTodo(input));
    }
  return (
      <div>
          {todos?.map((todo) => {
              return (<div>{ todo}</div>)
          })}
          <input value={input} onChange={handleOnChange} />
          <button onClick={handleOnAdd}>add todo</button>
    </div>
  )
}

export default TodoList