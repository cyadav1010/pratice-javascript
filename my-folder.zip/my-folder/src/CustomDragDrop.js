import React, { useState } from "react";

const CustomDragDrop = () => {
  const [items, setItems] = useState(["Item 1", "Item 2", "Item 3", "Item 4"]);
  const [draggingIndex, setDraggingIndex] = useState(null);
  const [hoverIndex, setHoverIndex] = useState(null);

    const handleDragStart = (index) => {
      console.log("handleDragStart", index);
    setDraggingIndex(index);
  };

    const handleDragEnter = (index) => {
        console.log("handleDragEnter", index);
    setHoverIndex(index);
  };

  const handleDragEnd = () => {
    if (hoverIndex !== null && draggingIndex !== null) {
      const updatedItems = [...items];
        const [draggedItem] = updatedItems.splice(draggingIndex, 1);
        console.log("draggedItem", draggedItem);
      updatedItems.splice(hoverIndex, 0, draggedItem);
      setItems(updatedItems);
    }
    setDraggingIndex(null);
    setHoverIndex(null);
  };

  return (
    <div>
      {items.map((item, index) => (
        <div
          key={index}
          draggable
          onDragStart={() => handleDragStart(index)}
          onDragEnter={() => handleDragEnter(index)}
          onDragEnd={handleDragEnd}
          style={{
            padding: "8px",
            margin: "4px",
            border: "1px solid #ccc",
            cursor: "grab",
            background:
              draggingIndex === index
                ? "#d3d3d3"
                : hoverIndex === index
                ? "#f0f0f0"
                : "#f9f9f9",
          }}
        >
          {item}
        </div>
      ))}
    </div>
  );
};

export default CustomDragDrop;
