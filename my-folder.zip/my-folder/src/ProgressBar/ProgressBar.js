import React,{useState,useEffect,useRef} from 'react'
import './style.css';
const ProgressBar = () => {
    const [bar, setBar] = useState(0);
    const timerRef = useRef(null);
    useEffect(() => {
      timerRef.current =  setInterval(() => {
         setBar((prevBar) => {
             if (prevBar == 100) {
                 clearInterval(timerRef);
                 return prevBar;
             }
             else {
               return  prevBar + 5;  
             }
            });
      }, 300);
        return () => {
            clearInterval(timerRef);
        }
    }, [])
    return (
        <div className='Progresscontainer'>
            <div className='progressWrapper'>
                <div style={{ transform: `translatex(${bar - 100}%)` }}
                    className='progress'
                >
                </div>
            </div>
        </div>
    )
}

export default ProgressBar