import React from 'react'

const Meeting = () => {
  return (
    <div>Meeting</div>
  )
}

export default Meeting