import React, { useState } from 'react';
// import './App.css';

function Jira() {
    const initialTasks = [
        {
            taskId: "123",
            assignee: "chandan",
            createdAt: "2024-12-18T10:00:00",
            updatedAt: "2024-12-18T10:00:00",
            title: "Write APIs",
            status: "Open",
        },
        {
            taskId: "124",
            assignee: "yogesh1",
            createdAt: "2024-12-18T11:00:00",
            updatedAt: "2024-12-18T11:00:00",
            title: "Add sort functionality",
            status: "In Progress",
        },
        {
            taskId: "125",
            assignee: "rahul",
            createdAt: "2024-12-18T12:00:00",
            updatedAt: "2024-12-18T12:00:00",
            title: "Add filter functionality",
            status: "Done",
        },
    ];

    const [tasks, setTasks] = useState(initialTasks);
    const [buckets] = useState(["Open", "In Progress", "Done"]);
    const [selectedTask, setSelectedTask] = useState(null);
    const [editTask, setEditTask] = useState(null);
    const [filterAssignee, setFilterAssignee] = useState("");
    const [sortBy, setSortBy] = useState("createdAt");

    const handleEditTask = (task) => {
        setSelectedTask(task);
        setEditTask({ ...task });
    };

    const updateKeyValue = (key, value) => {
        setEditTask((prev) => ({ ...prev, [key]: value }));
    };

    const handleSaveTask = () => {
        setTasks((prevTasks) =>
            prevTasks.map((task) =>
                task.taskId === editTask.taskId
                    ? { ...editTask, updatedAt: new Date().toISOString() }
                    : task
            )
        );
        setSelectedTask(null);
        setEditTask(null);
    };

    const filteredTasks = tasks
        .filter((task) => (filterAssignee ? task.assignee === filterAssignee : true))
        .sort((a, b) => new Date(b[sortBy]) - new Date(a[sortBy]));

    return (
        <div className="App">
            <h1>JIRA Dashboard</h1>

            <div className="filters">
                <label>
                    Filter by Assignee:
                    <input
                        type="text"
                        value={filterAssignee}
                        onChange={(e) => setFilterAssignee(e.target.value)}
                        placeholder="Enter assignee name"
                    />
                </label>
                <label>
                    Sort by:
                    <select value={sortBy} onChange={(e) => setSortBy(e.target.value)}>
                        <option value="createdAt">Created At</option>
                        <option value="updatedAt">Updated At</option>
                    </select>
                </label>
            </div>

            <div className="buckets">
                {buckets.map((bucket) => (
                    <div key={bucket} className="bucket">
                        <h2>{bucket}</h2>
                        {filteredTasks
                            .filter((task) => task.status === bucket)
                            .map((task) => (
                                <div key={task.taskId} className="task-card">
                                    <p><strong>Title:</strong> {task.title}</p>
                                    <p><strong>Assignee:</strong> {task.assignee}</p>
                                    <p><strong>Created At:</strong> {new Date(task.createdAt).toLocaleString()}</p>
                                    <p><strong>Updated At:</strong> {new Date(task.updatedAt).toLocaleString()}</p>
                                    <button onClick={() => handleEditTask(task)}>Edit Task</button>
                                </div>
                            ))}
                    </div>
                ))}
            </div>

            {editTask && (
                <div className="edit-task-form">
                    <h2>Edit Task</h2>
                    <label>
                        Title:
                        <input
                            type="text"
                            value={editTask.title}
                            onChange={(e) => updateKeyValue("title", e.target.value)}
                        />
                    </label>
                    <label>
                        Assignee:
                        <input
                            type="text"
                            value={editTask.assignee}
                            onChange={(e) => updateKeyValue("assignee", e.target.value)}
                        />
                    </label>
                    <button onClick={handleSaveTask}>Save</button>
                </div>
            )}
        </div>
    );
}

export default Jira;
