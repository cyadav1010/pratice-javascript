import React,{useState,useEffect} from 'react'
import { COUNTRY_DATA } from '../mock';
import './style.css';
// Render the list of countries and capitals in the random order on the UI.
// The aim of the game is to select the country and its capitals.
// The user can select 2 options. The default border color of an option should be #414141.
// Selected option should have blue color border.
// If the user selection is correct the selected options border color should change to #66cc99 and both options should disappear from the screen after 1000 ms.
// If the user selection is incorrect then the selected options border color should change to red and reset after 1000 ms.
// When there are no options left on the screen then show a message Congratulations
const CountryGame = () => {
    class person{
        constructor(name, age) {
            this.name = name; // Assign name property
            this.age = age;   // Assign age property
          }
    };

    const [initalData, setInitalData] = useState(COUNTRY_DATA);
    const [countryData, setCountryData] = useState([]);
    const [selectedFirstOption, setSelectedFirstOption] = useState(null);
    const [selectedSecondOption, setSelectedSecondOption] = useState(null);
    const getAllList=()=>{
        const allData=[];
       Object.keys(initalData)?.forEach((key)=>{
        let capital=initalData[key];
        allData.push(key);
        allData.push(capital);
       })
       let randomData =[];
       let len = allData.length;
       while(allData.length!=randomData.length){
        let rnd= Math.floor(Math.random()*len);
        let value=allData[rnd];
        if(!randomData.find((ele)=>ele==value)){
            randomData.push(value);
        }
       }
       console.log("randomData",randomData);
       setCountryData(randomData);
    };
    useEffect(() => {
        getAllList();
    }, []);
    const checkCorrectAnswer=()=>{
        let option1 = selectedFirstOption;
      let  option2= selectedSecondOption;
        let isCorrectAns = false;
        // let countryData1={}
        Object.keys(initalData)?.forEach((key)=>{
            if(key==option1 || initalData[key]==option1){
                if((key==option1 || initalData[key]==option1) && (key==option2 || initalData[key]==option2)){
                    isCorrectAns =true;
                   let countryDataTemp =  [...countryData];
                  let tempData = countryDataTemp.filter((data)=>data !== option1 && data !== option2
                  );
                  setCountryData(tempData);
                  setSelectedFirstOption(null);
                  setSelectedSecondOption(null);
                }
            }
        })
    };
    const handleClickData=(data)=>{
        if(!selectedFirstOption){
            setSelectedFirstOption(data);
        }else{
            setSelectedSecondOption(data);
        }
    }
    useEffect(() => {
        checkCorrectAnswer();
    }, [selectedFirstOption,selectedSecondOption]);
    useEffect(() => {
        console.log("countryData",countryData);
    }, [countryData])
  return (
    <div className='countryWrapper'>{countryData?.map((data)=>{
        return(
    <div className='country' onClick={()=>handleClickData(data)}>{data}</div>)
})}</div>
  )
}

export default CountryGame;