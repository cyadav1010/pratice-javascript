import logo from './logo.svg';
import './App.css';
import RenderFolder from './FolderStructure/RenderFolder';
import BoxData from './BoxData';
import ChartData from './Chart';
import FeatureFlag from './FeatureFlag/FeatureFlag';
import CountryGame from './CountryCapitalGame/Country-capital-game';
import ImageSliderApp from './ImageSlider';
import MemoryGame from './MemoryGame';
import AnimatedCircles from './AnimatedCircles';
import EventEmitter from './EventEmitter/EventEmitter';
import Counter from './ReduxEample/Counter';
import ReduxEample from './ReduxEample/Store';
import TicTac from './TicTac/TicTac';
import Jira from './Jira/Jira';
import ProductList from './ProductList/ProductList';
import DropdownExample from './DropdownExample';
import CustomDropdown from './Dropdown/CustomDropdown';
import AutoComplete from './Autosuggestion-compontent/AutoComplete';
import PaginationWrapper from './Pagination';
import FileStructure from './FileExplorer/FileStructure';
import NestedComments from './NestedComments/NestedComments';
import CircleDrawer from './Circle/Circle';
import ProgressBar from './ProgressBar/ProgressBar';
import NestedCheckbox from './NestedCheckbox/NestedCheckbox';
import Stepper from './Stepper/Stepper';
import CustomStepper from './Stepper/CustomStepper';
import ModalExample from './CustomHooks/ModalExample';
import CustomDragDrop from './CustomDragDrop';
import DynamicForm from './DynamicForm/DynamicForm';
import formConfig from './DynamicForm/formConfig';
import TicTacGame from './TicTacGame/TicTacGame';
import TodoList from './ReduxEample/TodoList';
import CircleClickApp from './Circle/CircleClickApp';
import SnakeAndLadderGame from './Programming/SnakeAndLadderGame';
import ProgressiveImage from './Programming/ProgressiveImage';
import SnakeLadderGrid from './Programming/SnakeLadderGrid';
import CustomProgressBar from './Programming/CustomProgressBar';
import CopyButton from './CustomHooks/CopyButton';
import ProductGrid from './ProductList/ProductGrid';
import VisibleProduct from './ProductList/VisibleProduct';
import GoogleCalendar from './googleCalendar/GoogleCalendar';
import Calendar from './googleCalendar/Calendar';
import ParentComponent from './ContextApiExample/ParentComponent';
import ExampleHoc from './HOC/ExampleHoc';
import DrogComponent from './HOC/DogImage';
import ImageExample from './ImageOptimization/ImageExample';
import BookMyShow from './BookMyShow/BookMyShow';
import MyCarousel from './Carousel/MyCarousel';
// import CustomCalendar from './googleCalendar/customCalendar';
// import ChartData from './ChartData';

function App() {


  var maxSubArray = function (nums) {
    // 
    // let currentSubarray =nums[0];
    // let totalSubArray= nums[0]
    // for(let i =0; i< nums.length; i++){
    // }

    let totalSum = 0;
    let maxValue = -1000000;
    for (let i = 0; i < nums.length; i++) {
      totalSum = totalSum + nums[i];
      maxValue = Math.max(totalSum, maxValue);
      if (totalSum < 0) {
        totalSum = nums[i];
        maxValue = Math.max(totalSum, maxValue);
      }
    }
    return maxValue;
  };

  // maxSubArray([-2, 1, -3, 4, -1, 2, 1, -5, 4]);
  return (
    <div className="App">
      {/* <BookMyShow /> */}
      {/* <MyCarousel/> */}
      {/* <CustomCalendar/> */}
      {/* <GoogleCalendar /> */}
      {/* <Calendar />
      <ParentComponent /> */}
      {/* <ImageExample/> */}
      {/* <ExampleHoc /> */}
      {/* <DrogComponent/> */}
      {/* <CustomProgressBar /> */}
      {/* <CopyButton /> */}
      {/* <VisibleProduct/> */}
      {/* <TicTacGame /> */}
      {/* <SnakeLadderGrid/> */}
      {/* <TodoList /> */}
      {/* <ProgressiveImage 
        lowQualitySrc="https://dummyimage.com/600x400/000/fff&text=chandan" 
        highQualitySrc="https://picsum.photos/300/200" 
        alt="Beautiful Landscape"
      /> */}
      {/* <CircleClickApp /> */}
      {/* <SnakeAndLadderGame/> */}
      {/* <FileStructure /> */}
      {/* <NestedComments /> */}
      {/* <CircleDrawer /> */}
      {/* <ProgressBar/> */}
      {/* <NestedCheckbox /> */}
      {/* <Stepper /> */}
      {/* <ModalExample /> */}
      {/* <CustomDragDrop /> */}
      {/* <DynamicForm config={formConfig}/> */}
      {/* <CustomStepper/> */}
      <RenderFolder/>
      {/* <BoxData />
      <ChartData />
      <FeatureFlag />
      <CountryGame />
      <ImageSliderApp />
      <MemoryGame />
      <AnimatedCircles />
      <EventEmitter /> */}
      {/* <Counter />
      <TicTac />
      <Jira /> */}
      {/* <ProductList /> */}
      {/* <DropdownExample /> */}
      {/* <CustomDropdown /> */}
      {/* <AutoComplete /> */}
      {/* <PaginationWrapper /> */}
      {/* <ReduxEample /> */}
      {/* <header className="App-header">
        <img src={logo} className="App-logo" alt="logo" />
        <p>
          Edit <code>src/App.js</code> and save to reload.
        </p>
        <a
          className="App-link"
          href="https://reactjs.org"
          target="_blank"
          rel="noopener noreferrer"
        >
          Learn React
        </a>
      </header> */}
    </div>
  );
}

export default App;
