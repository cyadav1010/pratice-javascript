import React,{useState,useEffect} from 'react'

const withLoader = (WrappedComponent, url) => {
    return (props) => {
        const [data, setData] = useState(null);
        useEffect(() => {
            async function getData() {
                const res = await fetch(url);
                const datas = await res.json();
                setData(datas);
            };
            getData();
        }, [])
        if (!data) {
            return <div> ... loading</div>
        }
        return <WrappedComponent {...props} data={data} />
    }

}

export default withLoader