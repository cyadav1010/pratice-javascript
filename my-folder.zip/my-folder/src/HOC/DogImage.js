import React from 'react'
import withLoader from './withLoader';

export const DogImage = (props) => {
    return (
        <div>{
            props.data.message.map((dog, index) => (
                <img src={dog} alt="Dog" key={index} />
            ))
        }</div>
    )
}
const DrogComponent = withLoader(DogImage, "https://dog.ceo/api/breed/labrador/images/random/6");
export default DrogComponent;