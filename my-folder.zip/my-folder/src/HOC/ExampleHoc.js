import React,{useState} from 'react'
import UserDisplay from './UserDisplay';
import { withDefaultName, withDefaultNameEx } from './withDefaultName';
const UserDisplayWithDefault = withDefaultNameEx(UserDisplay);
const ExampleHoc = ({ }) => {
    console.log("ExampleHoc");
    return (
        <>
            <UserDisplayWithDefault />
            <UserDisplayWithDefault name="John" />
        </>
    )
}

export default ExampleHoc


function useReducer(reducer, initialState) {
  const [state, setState] = useState(initialState);

  function dispatch(action) {
    const nextState = reducer(state, action);
    setState(nextState);
  }

  return [state, dispatch];
}
function Todos() {
  // const [todos, dispatch] = useReducer(todosReducer, []);

  function handleAddClick(text) {
    // dispatch({ type: 'add', text });
  }

  // ...
}