import React from 'react'

const UserDisplay = ({ name ,count,incrementCount}) => {
    return (
        <div>
            user: {name}
            <p>Count: {count}</p>
            <button onClick={incrementCount}>Increment Count</button>
        </div>
    )
}

export default UserDisplay