import React,{useState} from 'react';
export function withDefaultName(WrappedComponent) {
    console.log("wrappedcomponet");
    return function EnhancedComponent(props) {
        console.log("props", props);
        const defaultName = "guest";
        return <WrappedComponent {...props} name={props.name || defaultName} />
    }
}

export const withDefaultNameEx = (WrappedComponent) => {
    return (props) => {
        const [count, setCount] = useState(0);
         // Function to increment the count
    const incrementCount = () => {
      setCount((prevCount) => prevCount + 1);
    };
        return <WrappedComponent
            {...props}
            name={props.name || "chandan"}
            count={count}
            incrementCount={incrementCount}
        />
    }
}
