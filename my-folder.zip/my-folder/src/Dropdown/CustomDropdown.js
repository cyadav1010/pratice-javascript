import React, { useState, cloneElement, Children } from "react";

// Parent Dropdown Component
const Dropdown = ({ children }) => {
    const [isOpen, setIsOpen] = useState(false);

    // Function to toggle dropdown
    const toggleDropdown = () => setIsOpen((prev) => !prev);

    // Pass shared props (state and function) to children
    return (
        <div className="dropdown">
            {Children.map(children, (child) => {
                return cloneElement(child, { isOpen, toggleDropdown });
            })}
        </div>
    );
};

// DropdownToggle: Button to toggle dropdown visibility
const DropdownToggle = ({ toggleDropdown, children }) => {
    return (
        <button onClick={toggleDropdown} className="dropdown-toggle">
            {children}
        </button>
    );
};

// DropdownMenu: Renders dropdown menu based on isOpen state
const DropdownMenu = ({ isOpen, children }) => {
    return isOpen ? <div className="dropdown-menu">{children}</div> : null;
};

// DropdownItem: Individual menu items
const DropdownItem = ({ onClick, children }) => {
    return (
        <div onClick={onClick} className="dropdown-item">
            {children}
        </div>
    );
};

// App Component: Using Dropdown
const CustomDropdown = () => {
    return (
        <Dropdown>
            <DropdownToggle>Toggle Dropdown</DropdownToggle>
            <DropdownMenu>
                <DropdownItem onClick={() => alert("Item 1 Clicked")}>Item 1</DropdownItem>
                <DropdownItem onClick={() => alert("Item 2 Clicked")}>Item 2</DropdownItem>
                <DropdownItem onClick={() => alert("Item 3 Clicked")}>Item 3</DropdownItem>
            </DropdownMenu>
        </Dropdown>
    );
};

export default CustomDropdown;
