async function parallelLimit(tasks, limit) {
    // return promise //
    // we should run 2 task parallel
    return new promise((resolve, reject) => {
    let result = [];
    let activeTask = 0;
    let index = 0;
    let completedTask = 0;
    let runningTask = 0;
    function executeTask() {
        //
        if (index >= tasks.length) {
            if (activeTask == 0) {
                resolve(result);
            }
            return;
        }
        const currentIndex = index;
        const currentTask = tasks[index];

        currentTask().then((res) => {
            result[currentIndex] = res;
        }).catch((error) => {
            result[currentIndex] = error;
        }).finally(() => {
            activeTask--;
            executeTask();
        })
    }
    for (let i = 0; i < limit && i < tasks.length; i++) {
        executeTask();
    }
  })

}

function customMapLimit(tasks, limit) {
    return new Promise((resolve, rejected) => {
        let results = new Array(tasks.length);
        let completedTask = 0;
        let runningTask = 0;
        let index = 0;
        function runTasks() {
            while (runningTask < limit && index < tasks.length) {
                if (completedTask == tasks.length) {
                    return resolve(results);
                }
                let currentTask = tasks[index];
                index++;
                runningTask++;
                currentTask().then((res) => {
                    results[index] = res;
                }).catch((error) => {
                    results[index] = error;
                }).finally(() => {
                    runningTask--;
                    completed++;
                    runTasks();
                })
            }
        }
        runTasks();
    })
}

const tasks = [
    () => new Promise(resolve => setTimeout(() => resolve("Task 1"), 1000)),
    () => new Promise(resolve => setTimeout(() => resolve("Task 2"), 500)),
    () => new Promise(resolve => setTimeout(() => resolve("Task 3"), 200)),
    () => new Promise(resolve => setTimeout(() => resolve("Task 4"), 1500)),
    () => new Promise(resolve => setTimeout(() => resolve("Task 5"), 100))
];

// Run tasks with a concurrency limit of 2
customMapLimit(tasks, 2)
    .then(results => {
        console.log("All tasks completed:", results);
    })
    .catch(err => {
        console.error("Error:", err);
    });





function mapLimit(tasks, limit) {
    return new Promise((resolve, reject) => {
        const results = new Array(tasks.length); // to store results
        let running = 0;    // number of currently running tasks
        let index = 0;      // index of the next task to start
        let completed = 0;  // number of tasks completed

        function runNext() {
            // If all tasks have been completed, resolve with the results.
            if (completed === tasks.length) {
                return resolve(results);
            }

            // Start as many tasks as possible up to the concurrency limit.
            while (running < limit && index < tasks.length) {
                const currentIndex = index++;  // capture the current task's index
                running++;

                // Execute the task. Each task is a function that returns a promise.
                tasks[currentIndex]()
                    .then((result) => {
                        results[currentIndex] = result;
                    })
                    .catch((error) => {
                        // You can change this behavior if needed.
                        // For example, to reject the entire promise immediately:
                        // return reject(error);
                        results[currentIndex] = error;
                    })
                    .finally(() => {
                        running--;
                        completed++;
                        runNext(); // try to start another task if available.
                    });
            }
        }

        // Start the initial batch of tasks.
        runNext();
    });
}



function customMapLimit(tasks, limit) {
    return new Promise((resolve, rejected) => {
        let results = new Array(tasks.length);
        let completedTask = 0;
        let runningTask = 0;
        let index = 0;
        function runTasks() {
            while (runningTask < limit && index < tasks.length) {
                if (completedTask == tasks.length) {
                    return resolve(results);
                }
                let currentTask = tasks[index];
                index++;
                runningTask++;
                currentTask().then((res) => {
                    results[index] = res;
                }).catch((error) => {
                    results[index] = error;
                }).finally(() => {
                    runningTask--;
                    completed++;
                    runTasks();
                })
            }
        }
        runTasks();
    })
}