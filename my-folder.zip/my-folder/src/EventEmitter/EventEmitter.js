import React from 'react'

const EventEmitter = () => {
    class Emitter{
      constructor(){
        // this._subscriptions = new Map();
        this.events = {};
      }
      subscribe(eventName, listener){
       if(!this.events.hasOwnProperty(eventName)){
        this.events[eventName]=[]
       }
       this.events[eventName].push(listener);
      }
      emit(eventName,...args){
        if(!this.events[eventName]) return ;
        this.events[eventName].forEach(listener =>listener(...args));
      }
    }
    const emitter = new Emitter();

    // Listener functions
    const greet = (name) => console.log(`Hello, ${name}!`);
    const farewell = (name) => console.log(`Goodbye, ${name}!`);
    
    // Subscribing to events
    emitter.subscribe('greet', greet);
    emitter.subscribe('farewell', farewell);
    
    // Emitting events
    emitter.emit('greet', 'Alice'); // Output: Hello, Alice!
    emitter.emit('farewell', 'Bob'); // Output: Goodbye, Bob!
    
    // Unsubscribe from an event
    // emitter.off('greet', greet);
    emitter.emit('greet', 'Charlie'); // No output
    
    // Subscribing to a one-time event
    // emitter.once('greet', greet);
    emitter.emit('greet', 'David'); // Output: Hello, David!
    emitter.emit('greet', 'Eve');   // No output (listener removed)
// sub1.release();
  return (
    <div>Emitter</div>
  )
}

export default EventEmitter