function getUserById(id, callback) {
  // simulating async request
  const randomRequestTime = Math.floor(Math.random() * 100) + 200;

  setTimeout(() => {
    callback("User" + id)
  }, randomRequestTime);
}
const chop = (arr, limit) => {
  let result = []
  let len = arr.length
  let incr = limit
  for (let i = 0; i < len; i += incr) {
    console.log("i", i)
    let tempArr = []
    for (let j = i; j < i + incr && j < len; j++) {
      console.log("j", j)
      tempArr.push(arr[j])
    }
    result.push(tempArr)
  }
  return result
}

let res = chop([1, 2, 3, 4, 5], 2)
async function mapLimit(inputs, limit, iterateeFn, callback) {
  // write your solution here
  let index = 0;
  let resultList = [];
  let chopInputs = chop(inputs, limit);

  async function processArrayWithPromises(arr, iterateeFn) {
    const promises = [];
    for (let i = 0; i < arr.length; i++) {
      const item = arr[i];
      promises.push(
        new Promise((resolve) => {
          iterateeFn(item, resolve)
        })
      )
    }
    const results = await Promise.all(promises);
    return results
  };
  for (let i = 0; i < chopInputs.length; i++) {
    let result = await processArrayWithPromises(chopInputs[i], iterateeFn);
    console.log("result==>", result);
    // let result = await Promise.all(chopInputs[i]);
    resultList.push(...result);
  }
  callback(resultList);
}

mapLimit([1, 2, 3, 4, 5], 2, getUserById, (allResults) => {
  console.print('output:', allResults) // ["User1", "User2", "User3", "User4", "User5"]
})

//  [1,2,3,4,5]
//   [1,2],[3,4],[5]
// Execute async tasks in Sequence
function createAsyncTask() {
  const value = Math.floor(Math.random() * 10);

  return new Promise((resolve, reject) => {
    setTimeout(() => {
      if (value < 5) {
        reject(`Error ${value}`);
      } else {
        resolve(value * 1000);
      }
    }, value * 1000);
  });
}

let tasks = [
  createAsyncTask(),
  createAsyncTask(),
  createAsyncTask(),
  createAsyncTask(),
  createAsyncTask(),
  createAsyncTask()
];
async function asyncSequence(tasks, callback) {
  let errorList = [];
  let result = [];
  for (let index = 0; index < tasks.length; index++) {
    try {
      const ans = await tasks[index];
      result.push(ans);
    } catch (error) {
      errorList.push(error);
    }
  }
  console.log("calling")
  callback(errorList, result)
}

async function asyncParallel(tasks, callback) {
  const results = await Promise.allSettled(tasks);
  let successList = [];
  let errorList = [];
  for (const result in results) {
    if (result?.status === "fulfilled") {
      successList.push(result.value)
    } else {
      errorList.push(result.value)
    }
  }
  callback(errorList, successList)
}



asyncParallel(tasks, (error, result) => {
  console.log("error", error);
  console.log("result", result);
})
// function asyncSequence(tasks, callback){
//   let isTaskRunng = false;
//   let index = 0;
//   // while()
//   tasks[0].then((resolve,rejected)=>{

//   })
//   for (let index = 0; index < tasks.length; index++) {

//   }


// }

// const results = await Promise.allSettled(tasks);
asyncSequence(tasks, (error, result) => {
  console.log("error", error);
  console.log("result", result);
})


// if (typeof Promise.all !== 'function') {
//   Promise.all = function(promises) {
//     return new Promise(function(resolve, reject) {
//       if (!Array.isArray(promises)) {
//         return reject(new TypeError('Argument to Promise.all must be an array'));
//       }
//       if (promises.length === 0) {
//         // If empty, resolve with an empty array
//         return resolve([]);
//       }

//       let results = [];
//       let remaining = promises.length;

//       // Helper function to store results
//       function processResult(index, value) {
//         results[index] = value;
//         remaining--;
//         if (remaining === 0) {
//           resolve(results);
//         }
//       }

//       for (let i = 0; i < promises.length; i++) {
//         // Ensure any value is wrapped in a promise
//         Promise.resolve(promises[i])
//           .then(value => processResult(i, value))
//           .catch(error => reject(error));
//       }
//     });
//   };
// }


var maxSubArray = function (nums) {
  // 
  let totalSum = 0;
  let maxValue = -1000000;
  for (let i = 0; i < nums.length; i++) {
    totalSum = totalSum + nums[i];
    maxValue = Math.max(totalSum, maxValue);
    if (totalSum < 0) {
      totalSum = nums[i];
      maxValue = Math.max(totalSum, maxValue);
    }
  }
  return maxValue;
};

maxSubArray([-2, 1, -3, 4, -1, 2, 1, -5, 4]);