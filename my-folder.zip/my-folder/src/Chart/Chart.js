import React from 'react'

const Chart = ({data}) => {
    console.log("data",data);
  return (
    <div style={{backgroundColor:data?.colour,width: '60px' ,height: `${data?.ticketCount*10}px`}}>{data?.name}</div>
  )
}

export default Chart