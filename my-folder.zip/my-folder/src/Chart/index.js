import React,{useState} from 'react'
import CHART_DATA from '../mock';
import Chart from './Chart';
import './style.css';

const ChartData = () => {
    const [data, setData] = useState(CHART_DATA);
    const [showChat, setshowChat] = useState(false);
const handleClickToggle=()=>{
    setshowChat(!showChat);
}

  return (
    <>
    <button className='botton' onClick={()=>handleClickToggle()}>Toggle Chat</button>
    {showChat && 
    <>
    <div className='chart-container'>
    <div className='chartWrapper'>{data?.map((ele)=>(
        <Chart data ={ele}/>
    ))}
    </div>
    <div className='x-axis-label'>No of Tickes</div>
    <div className='y-axis-label'>Deparments</div>
    </div>
    </>
    }
    </>
  )
}

export default ChartData;