import React from 'react'

const BarChart = ({data}) => {
  return (
    <div className='chart-container'>
        
    </div>
  )
}

export default BarChart