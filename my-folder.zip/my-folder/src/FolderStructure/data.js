export const folderStructure = {
    src: {
      components: {
        "Editor.jsx": null,
        "Toolbar.jsx": null,
        "UserHighlights.jsx": null,
        "DocumentManager.jsx": null,
        subComponents: {
          modals: {
            "SaveModal.jsx": null,
            "ErrorModal.jsx": null,
          },
          "Button.jsx": null,
          "InputField.jsx": null,
        },
      },
      hooks: {
        "useUndoRedo.js": null,
        "useWebSocket.js": null,
        "useDocumentState.js": null,
        "useLocalStorage.js": null,
      },
      contexts: {
        "EditorContext.jsx": null,
        "ThemeContext.jsx": null,
      },
      utils: {
        validation: {
          "validateInput.js": null,
          "checkPermissions.js": null,
        },
        formatting: {
          "formatDate.js": null,
          "formatText.js": null,
        },
        "conflictResolution.js": null,
        "textOperations.js": null,
      },
      tests: {
        components: {
          "Editor.test.js": null,
          "Toolbar.test.js": null,
        },
        hooks: {
          "useUndoRedo.test.js": null,
        },
        utils: {
          "validateInput.test.js": null,
        },
      },
      styles: {
        "App.css": null,
        "Editor.css": null,
        themes: {
          "dark.css": null,
          "light.css": null,
        },
      },
      "App.jsx": null,
      "index.js": null,
    },
    public: {
      assets: {
        images: {
          "logo.png": null,
          "background.jpg": null,
        },
        fonts: {
          "Roboto.ttf": null,
        },
      },
      "index.html": null,
    },
    config: {
      "webpack.config.js": null,
      "babel.config.js": null,
    },
    "package.json": null,
    "README.md": null,
  };
  