import React, { useState } from 'react'
import { folderStructure } from './data'
import RenderFolderRecur from './RenderFolderRecur';

const RenderFolder = () => {
    const [folderData, setFolderData] = useState(folderStructure);
    const renderComponent =(data={})=>{
      const allKeysData = Object.keys(data);
       allKeysData.map((key)=>{
        if(data[key]!=null){
          return  renderComponent(data[key]);
        }else{
            console.log("key==>",key);
            return <span>key</span> ;
        }
       })
    }
  return (
    <div>
      {/* {renderComponent(folderData)} */}
    <RenderFolderRecur folderData={folderData}/>
      {/* {
      Object.keys(folderData).map((key)=>{return <div>{key}</div>})
      } */}
    </div>
  )
}

export default RenderFolder;