import React, { useState } from 'react'
import './folder.css';
const RenderFolderRecur = ({ folderData }) => {
  // const [collapse, setCollapse] = useState([]);
  // const [isCollapse, setisCollapse] = useState(false);
  const [collapseState, setCollapseState] = useState({});
  return (
    <div className='parent'>
      {Object.keys(folderData).map((key) => {
        if (folderData[key] != null) {
          return <>
            <div className='folder' onClick={() =>
               setCollapseState((prevState)=>({...prevState,[key]:!prevState[key]}))
            }
            >{key}</div>
            {collapseState[key] && (
              <div className="child">
                <RenderFolderRecur folderData={folderData[key]} />
              </div>
            )}
          </>
        }
        return <div className='folder'>{key}</div>

      })}
    </div>
  )
}

export default RenderFolderRecur




// import React, { useState } from 'react';
// import './folder.css';

// const RenderFolderRecur = ({ folderData }) => {
//   const [collapseState, setCollapseState] = useState({});

//   return (
//     <div className="parent">
//       {Object.keys(folderData).map((key) => {
//         if (folderData[key] !== null) {
//           return (
//             <React.Fragment key={key}>
//               <div
//                 className="folder"
//                 onClick={() =>
//                   setCollapseState((prevState) => ({
//                     ...prevState,
//                     [key]: !prevState[key]
//                   }))
//                 }
//               >
//                 {key}
//               </div>
//               {collapseState[key] && (
//                 <div className="child">
//                   <RenderFolderRecur folderData={folderData[key]} />
//                 </div>
//               )}
//             </React.Fragment>
//           );
//         }
//         return (
//           <div className="folder" key={key}>
//             {key}
//           </div>
//         );
//       })}
//     </div>
//   );
// };

// export default RenderFolderRecur;
