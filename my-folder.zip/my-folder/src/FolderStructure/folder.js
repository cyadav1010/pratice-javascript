import React from 'react'

const folder = (folderName) => {
  return (
    <div>{folderName}</div>
  )
}

export default folder