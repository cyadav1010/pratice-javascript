import React,{useRef,useState} from 'react'

const VirtualizedList = ({ item, itemHeight = 50, containerHeight = 400 }) => {
    const [scrollTop, setScrollTop] = useState(0);
    const containerRef = useRef(null);
    const handleScroll = (e) => {
        console.log("scrollTop",e.target.scrollTop);
        setScrollTop(containerRef.current.scrollTop)
    }
    return (
        <div>
            <div
                ref={containerRef}
                onScroll={handleScroll}
            >
            </div>
        </div>
    )
}

export default VirtualizedList