import React from "react";

const TaskRunner = () => {
  // DO CHANGE THE CLASS NAME
  class TaskRunner {
    constructor(concurrency) {
      // write your code below
      this.limit = concurrency;
      this.queue = [];
      this.inital = 0;
    }

    runTask(task) {
      this.inital = this.inital + 1;
      task().then((res) => {
        if (this.inital > 0) {
          this.inital = this.inital - 1;
        }
        console.log("this.queue", this.queue);
        if (this.queue.length > 0) {
          let currTask = this.queue[0];
          this.runTask(currTask);
          this.queue.shift();
        }
        // if(this.queue.length>0){
        //     this.queue.forEach(excTask => {
        //         push(excTask)
        //     });
        // }
      });
    }

    push(task) {
      if (this.inital < this.limit) {
        this.runTask(task);
        // this.inital = this.inital + 1;
        // task().then((res)=>{
        //     if(this.inital>0){
        //     this.inital =this.inital -1;
        //     }
        //     if(this.queue.length>0){
        //         this.queue.forEach(element => {

        //         });
        //     // let currTask = this.queue[0];
        //     // cu
        //     }
        // })
      } else {
        this.queue.push(task);
      }
    }
  }
  const ex = new TaskRunner(3);

  const delay = (ms) => {
    return new Promise((resolve, rejeceted) => {
      setTimeout(() => {
        resolve(ms);
      }, ms);
    });
  };
  // Simulated async tasks
  const t1 = async () => {
    console.log("t1 started");
    await delay(2000);
    console.log("t1 finished");
  };
  const t2 = async () => {
    console.log("t2 started");
    await delay(1000);
    console.log("t2 finished");
  };
  const t3 = async () => {
    console.log("t3 started");
    await delay(1500);
    console.log("t3 finished");
  };
  const t4 = async () => {
    console.log("t4 started");
    await delay(1000);
    console.log("t4 finished");
  };
  const t5 = async () => {
    console.log("t5 started");
    await delay(500);
    console.log("t5 finished");
  };

  // Add tasks to the executor
  ex.push(t1); // Starts immediately
  ex.push(t2); // Starts immediately
  ex.push(t3); // Starts immediately
  ex.push(t4); // Waits until at least one task finishes
  ex.push(t5); // Waits until another task finishes
  return <div>TaskRunner</div>;
};

export default TaskRunner;

function asyncFunc(time) {
  return new Promise(function (resolve, reject) {
    setTimeout(function () {
      resolve(time);
    }, time);
  });
}

let list = [asyncFunc(1200), asyncFunc(3600), asyncFunc(2400)];

function myPromiseAll(tasks) {
  let result = [];
  let itemsCompleted = 0;
  return new Promise((resolve, reject) => {
    tasks?.forEach((task, index) => {
      task.then((res) => {
        result[index] = res;
        itemsCompleted++;
        if (itemsCompleted == task.length) {
          resolve(result);
        }
      }).catch(err => {
        reject(err);
      })
    });
  });
}

myPromiseAll(list).then((res) => console.log(res));

