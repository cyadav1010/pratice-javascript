import React,{useState} from 'react'
import { explorer } from './folderData'

const Folder = ({ data }) => {
    const [isOpened, setIsOpened] = useState(false)
  return (
      <div>
          {data?.isFolder && <span onClick={()=>setIsOpened(!isOpened)}>📁</span> }
          {data?.name}
          {isOpened && data.items.map((item) => {
                return <Folder data={item}/>
              })}
      </div>
  )
}

export default Folder