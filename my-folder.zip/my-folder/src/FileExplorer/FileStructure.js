import React from 'react'
import Folder from './Folder'
import { explorer } from './folderData'
const FileStructure = () => {
  return (
      <div><Folder data={explorer} /></div>
  )
}

export default FileStructure