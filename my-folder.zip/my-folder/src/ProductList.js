import React, { useRef, useState,useEffect } from 'react'

const ProductList = () => {
    const [products, setProducts] = useState([]);
    const [hasMore, setHasMore] = useState(true);
    const [page, setPage] = useState(0);
    const elementRef = useRef(null);
    const onIntersection = (entries) => {
        const firstEntries = entries[0];
        if (firstEntries.isIntersecting && hasMore) {
            fetchMoreItems();
        }
    };
    useEffect(() => {
        const observer = new IntersectionObserver(onIntersection);
        if (observer && elementRef.current) {
            observer.observe(elementRef.current);
        }
        return () => {
            observer.disconnect();
        }
    }, [products])
   
    const fetchMoreItems = async () => {
    try {
        const res = await fetch(`https://dummyjson.com/products?limit=10&skip=${page * 10}`);
        const data = await res.json();

        if (data?.products?.length === 0) {
            setHasMore(false);
        } else {
            setProducts((prevItems) => [...prevItems, ...data.products]);
            setPage((prevPage) => prevPage + 1);
        }
    } catch (error) {
        console.error("Error fetching more items:", error);
    }
};

    return (
        <div>
            {
                products?.map((item) => {
                    return (<div>
                         {item.title}
                        {item.description}
                        {item.title}
                    </div>)
                })
            }
            {hasMore &&
                <div ref={elementRef}>load more items  </div>
            }
        </div>
    )
}

export default ProductList