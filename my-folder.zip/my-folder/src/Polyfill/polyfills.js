
Array.prototype.myMap = function (callback) {
    if (typeof callback !== "function") {
        throw new TypeError(`${callback} is not a function`);
    }
    let result = [];
    for (let i = 0; i < this.length; i++) {
        result.push(callback(this[i], i, this));
    }
    return result;
}

let arr = [1, 2, 3, 4, 5, 6];
const res = arr.myMap(num => num * num);
console.log("res", res);

const person = {
    fullName: function (city, country) {
        return `${this.firstName} ${this.lastName} from ${city}, ${country}`;
    }
};

const john = { firstName: "John", lastName: "Doe" };

console.log(person.fullName.call(john, "New York", "USA"));
// Output: John Doe from New York, USA


Function.prototype.myCall = function (thisArgs, ...argsArray) {

    thisArgs.fn = this;
    const result = thisArgs.fn(...argsArray);
    return result;
}

Function.prototype.myApply = function (thisArgs, argsArray) {
    console.log("thisArgs", thisArgs);
    console.log("argsArray", argsArray);
    thisArgs.fn = this;
    const result = argsArray ? thisArgs.fn(argsArray) : thisArgs.fn();
    delete thisArgs.fn;
    return result;
}

const personObj = {
    firstName: "chandan",

}
function fullName(lastName) {
    return `${this.firstName} ${lastName} `
}
fullName.apply(personObj, "raj");


Function.prototype.myCall=function (thisArgs,argsArray) {

    if (typeof this !== "function") {
        throw new TypeError(this + " is not callable");
    }
    thisArgs.fun = this;
    const result =  argsArray ? thisArgs.fun(...argsArray) : thisArgs.fun();
    delete thisArgs.fun;
    return result;
}

Function.prototype.myBind=function (context,argsArray) {
    const originalFunction = this;
    return function (...callTimeArgs) { 
        const allArgs = [...callTimeArgs, ...argsArray];
        return originalFunction.call(context, allArgs);
    }

}

const PromiseState = {
    PENDING: "PENDING",
    FULFILLED: "FULFILLED",
    REJECTED: "REJECTED",
}

class customPromise {
    constructor(executor) {
        this.state = "pending";
        this.value = null;
        this.callbacks = [];
        const resolve = this.resolve.bind(this);
        executor(resolve);
    }
    then(onFulfilled) {
        if (this.state == "fulfilled") {
            onFulfilled(this.value);
        } else {
            this.callbacks.push(onFulfilled);
        }
        return this;
    }
    resolve = (value) => {
        if (this.state == "pending") {
            this.state == "fulfilled";
            this.value = value;
        }
    }

}









const promise1 = new Promise((resolve, rejected) => { setTimeout(() => { resolve("hello") }, 50) })
promise1.then((res) => { console.log("ress", res) }).catch((err) => { console.log("errr", err) })










class myCustomPromise {
    constructor(executor) {
        this.state = "pending";
        this.value = null;
        this.callbacks = [];
        this.reason = null;
        this.rejectedCallbacks = [];
        const resolve = this.resolve.bind(this);
        const rejected = this.rejected.bind(this);
       try {
           executor(resolve, rejected);
       } catch (error) {
           rejected(error);
       }

    }
    resolve(value) {
        if (this.state == "pending") {
            this.state == "fullfilled";
            this.value = value;
            this.callbacks.forEach((cb) => cb(value));
        }
    }
    rejected(reason) {
        if (this.state == "rejected") {
            this.reason = reason;
            this.rejectedCallbacks.forEach((cb) => cb(reason));
        }
    }
    then(onFullFillment) {
        if (this.state == "fullfilled") {
            onFullFillment(this.value);
        } else {
            this.callbacks.push(onFullFillment);
        }
        return this;
    }
    catch(onRejected) {
        if (this.state == "rejected") {
            onRejected(this.reason);
        } else if (this.state == "pending") {
            this.errorCallbacks.push(onRejected);
        }
        return this;
    }
}

