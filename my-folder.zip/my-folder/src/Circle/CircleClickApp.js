import React, { useState } from "react";

const CircleClickApp = () => {
  const [circles, setCircles] = useState([]);
  const circleRadius = 30; // Fixed radius for each circle

  // Function to detect overlap with existing circles
  const isOverlapping = (x, y) => {
    return circles.some((circle) => {
      const dx = circle.x - x;
      const dy = circle.y - y;
      const distance = Math.sqrt(dx * dx + dy * dy);
      return distance < circleRadius * 2; // Overlapping if closer than 2*radius
    });
  };

  // Handle click to create a circle
  const handleClick = (event) => {
    const { clientX, clientY } = event;

    const newCircle = {
      x: clientX,
      y: clientY,
      color: isOverlapping(clientX, clientY) ? "red" : "blue",
    };
    setCircles((prevCircles) => [...prevCircles, newCircle]);
  };

  return (
    <div
      onClick={handleClick}
      style={{
        width: "100vw",
        height: "100vh",
        background: "#f9f9f9",
        position: "relative",
      }}
    >
      {circles.map((circle, index) => (
        <div
          key={index}
          style={{
            position: "absolute",
            left: circle.x - circleRadius,
            top: circle.y - circleRadius,
            width: circleRadius * 2,
            height: circleRadius * 2,
            borderRadius: "50%",
            backgroundColor: circle.color,
            border: "1px solid black",
          }}
        ></div>
      ))}
    </div>
  );
};

export default CircleClickApp;
