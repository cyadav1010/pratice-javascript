import React, { useRef, useState } from "react";

const CircleDrawer = () => {
  const [isDrawing, setIsDrawing] = useState(false);
  const [startPoint, setStartPoint] = useState(null);
  const [circle, setCircle] = useState(null);
  const canvasRef = useRef(null);

  const handleMouseDown = (e) => {
    if (e.button !== 0) return; // Ensure it's the left mouse button
    const rect = canvasRef.current.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;

    setStartPoint({ x, y });
    setCircle({ x, y, radius: 0 }); // Initialize the circle
    setIsDrawing(true);
  };

  const handleMouseMove = (e) => {
    if (!isDrawing || !startPoint) return;

    const rect = canvasRef.current.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;

    const radius = Math.sqrt(
      Math.pow(x - startPoint.x, 2) + Math.pow(y - startPoint.y, 2)
    );

    setCircle({ x: startPoint.x, y: startPoint.y, radius });
  };

  const handleMouseUp = () => {
    setIsDrawing(false); // Stop drawing when the mouse button is released
  };

  return (
    <div>
      <div
        ref={canvasRef}
        onMouseDown={handleMouseDown}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
        style={{
          width: "50vw",
          height: "50vh",
          border: "1px solid black",
          position: "relative",
          overflow: "hidden",
        }}
      >
        {circle && (
          <div
            style={{
              position: "absolute",
              left: `${circle.x - circle.radius}px`,
              top: `${circle.y - circle.radius}px`,
              width: `${circle.radius * 2}px`,
              height: `${circle.radius * 2}px`,
              borderRadius: "50%",
              border: "2px solid blue",
            }}
          ></div>
        )}
      </div>
    </div>
  );
};

export default CircleDrawer;
