import React, { useState } from 'react'
import './style.css';
const TicTacGame = () => {
    let size = 4;
    const grid1 = Array.from({ length: size }, (_, row) => Array.from({ length: size }, (_, col) => row * size + col + 1));
    console.log("grid1==>", grid1);
    const gridArray = new Array(size).fill(new Array(size).fill(' '));
    const [grid, setGrid] = useState(gridArray);
    const [userTurn, setUserTurn] = useState('X');
    console.log("grid==>", grid[1]);
    function checkWinner(grid) {
         console.log("grid==>", grid[1]);
        let rowLen = grid.length;
        let colLen = grid[0].length;
        for (let row = 0; row < rowLen; row++) {
            let currValue = grid[row][0];
            let count = 0;
            for (let col = 0; col < colLen; col++) {
                if (grid[row][col] == currValue) {
                    count++;
                }
            }
            if (count == rowLen) {
                return true;
            }
        }
        for (let col = 0; col < colLen; col++) {
            let currValue = grid[0][col];
            let count = 0;
            for (let row = 0; row < rowLen; row++) {
                if (grid[row][col] == currValue) {
                    count++;
                }
            }
            if (count == rowLen) {
                return true;
            }
        }

      let   currValue = grid[0][0];
      let  count = 0;
        for (let row = 0, col = 0; row < rowLen && col < colLen; row++, col++) {
            if (currValue == grid[row][col]) {
                count++;
            }
        }
        if (count == rowLen) {
            return true;
        }
         currValue = grid[rowLen - 1][0];
         count = 0;
        for (let row = rowLen - 1, col = 0; row >= 0, col < colLen; row--, col++) {
            if (currValue == grid[row][col]) {
                count++;
            }
        }
        if (count == rowLen) {
            return true;
        }
        return false;
    };
    const handleOnClick = (row, col) => {
        console.log("row,col", row, col);
        let tempGrid = JSON.parse(JSON.stringify(grid));
        if (userTurn == "X") {
            tempGrid[row][col] = "X";
            setUserTurn("0");
        } else {
            tempGrid[row][col] = "0";
            setUserTurn("X");
        }
        if (checkWinner(tempGrid)) {
            console.log("winner user==>", userTurn);
        }
        setGrid(tempGrid);

        // tempGrid[][]
     };
    return (
        <div className='ticTacGameWrapper'>
            <div className='gridContainer'>
                {grid?.map((ele, row) => {
                    return (
                        <div className='gridBox'>
                            {ele?.map((item, col) => {
                                return (<div className='boxItem' onClick={()=>handleOnClick(row,col)}>{item}</div>)
                            })}
                        </div>
                    )
                })}
            </div>
        </div>
    )
}

export default TicTacGame