import React from 'react'
import CheckoutStepper from './CheckoutStepper'
import CustomStepper from './CustomStepper';

const Stepper = () => {
    const CHECKOUT_STEPS = [
        {
        name: "Cutomer info",
            // component: () => <Example1 />
         component: Example1
        },
        {
        name: "Shipping info",
        component: () => <div>Provide your Shipping details.</div>
        },
        {
        name: "payment info",
        component: () => <div>Provide your payment details.</div>
        },
        {
        name: "checkout info",
        component: () => <div>Provide your checkout details.</div>
        }
    ];
   
    return (
        <div><CheckoutStepper stepsConfig={CHECKOUT_STEPS} /></div>
    )
}

export default Stepper;

const Example1 = ({ onPrev, onNext }) => {
    return (
        <>
            <h1>Hello 1</h1>
            {/* <div>
                <button onClick={onPrev}>Prev</button>
                <button onClick={onNext}>Next</button>
            </div> */}
        </>
    );
};

const Example2 = ({ onPrev, onNext }) => {
    return (
        <>
            <h1>Hello 2</h1>
            <div>
                <button onClick={onPrev}>Prev</button>
                <button onClick={onNext}>Next</button>
            </div>
        </>
    );
};

const Example3 = ({ onPrev, onNext }) => {
    return (
        <>
            <h1>Hello 3</h1>
            <div>
                <button onClick={onPrev}>Prev</button>
                <button onClick={onNext}>Next</button>
            </div>
        </>
    );
};

const Example4 = ({ onPrev, onNext }) => {
    return (
        <>
            <h1>Hello 4</h1>
            <div>
                <button onClick={onPrev}>Prev</button>
                <button onClick={onNext}>Next</button>
            </div>
        </>
    );
};

const Example5 = ({ onPrev, onNext }) => {
    return (
        <>
            <h1>Hello 5</h1>
            <div>
                <button onClick={onPrev}>Prev</button>
                <button onClick={onNext}>Next</button>
            </div>
        </>
    );
};