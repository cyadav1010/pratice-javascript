import React, { useState, useEffect, useRef } from 'react';
import './style.css';

const CheckoutStepper = ({ stepsConfig = [] }) => {
    const [currentStep, setCurrentStep] = useState(0);
    const [isCompleted, setisCompleted] = useState(false);
    const [margins, setMargins] = useState({
        marginLeft: 0,
        marginRight: 0,
    })
    const stepsCount = stepsConfig.length;
    const ActiveComponent = stepsConfig[currentStep - 1]?.component;
    const stepRef = useRef([]);
    const handleNext = () => {
        setCurrentStep((prev) => {
            if (prev === stepsConfig.length) {
                setisCompleted(true);
                return prev;
            } else {
                return prev + 1;
            }
        });
    };
    const handlePrev = () => {
        setCurrentStep((prev) => {
            if (prev === 0)
                return 0;
            else return prev - 1;
        });
    };
    const calculateProgressWidth = () => {
        if (currentStep <= 1) return 0;
        const res = ((currentStep - 1) / (stepsConfig.length - 1)) * 100;
        console.log("res==>", res);
        return res;
    }
    // useEffect(() => {
    //     setMargins({
    //         marginLeft: stepRef.current[0].offsetWidth / 2,
    //         marginRight: stepRef.current[stepsConfig.length - 1].offsetWidth / 2,
    //     });
    //     console.log("stepRef.current[0].offsetWidth", stepRef.current[0].offsetWidth);
    //     console.log("stepRef.current[0].offsetWidth1", stepRef.current[stepsConfig.length-1].offsetWidth);
    // }, [stepRef, stepsConfig.length])

    useEffect(() => {
        if (stepRef.current[0] && stepRef.current[stepsConfig.length - 1]) {
            const firstStepWidth = stepRef.current[0].offsetWidth;
            const lastStepWidth = stepRef.current[stepsConfig.length - 1].offsetWidth;

            setMargins({
                marginLeft: firstStepWidth / 2,
                marginRight: lastStepWidth / 2,
            });
        }
    }, [stepsConfig.length, stepRef.current]);
    useEffect(() => {
        console.log('Margins:', margins);
        console.log('Total Width:', 700 - (margins.marginLeft + margins.marginRight));
    }, [margins]);
    return (
        <div>
            <div className='stepperWrapper'>
                {stepsConfig.map((step, index) => {
                    return <>
                        <div key={step.name} ref={(el) => (stepRef.current[index] = el)} className={`step ${index + 1 < currentStep ? "completed" : ""} ${currentStep === index + 1 ? "active" : ""} `}>
                            <div className='step_number'>{index + 1 > currentStep ? index + 1 : "✓"}</div>
                            <div>{step?.name}</div>
                        </div>
                    </>
                })}
                <div className='progress-bar' style={{
                    width: `calc(100% - ${margins.marginLeft + margins.marginRight}px)`,
                    marginLeft: margins.marginLeft,
                    marginRight: margins.marginRight,
                }}>
                    <div className='progresswrapper' style={{ width: `${calculateProgressWidth()}%` }}></div>
                </div>
            </div>
            {ActiveComponent && <ActiveComponent />}
            <button onClick={() => handlePrev()}>prev</button>
            <button onClick={() => handleNext()}>next</button>
        </div>
    )
}

export default CheckoutStepper;