const data = [
    {
        value: "root",
        isSelected: false,
        display: "root",
        currentId: 1,
        prevId: null,
        indeterminate: false,
        child: [
            {
                value: "child 1 of root",
                display: "child 1 of root",
                isSelected: false,
                indeterminate: false,
                currentId: 2,
                prevId: 1,
                child: [
                    {
                        value: "nested child 1 of root",
                        display: "nested child 1 of root",
                        isSelected: false,
                        indeterminate: false,
                        currentId: 3,
                        prevId: 2,
                        child: [
                            {
                                value: "deeply nested child 1 of root",
                                display: "deeply nested child 1 of root",
                                isSelected: false,
                                indeterminate: false,
                                currentId: 4,
                                prevId: 3,
                                child: [
                                    {
                                        value: "deeply  deeply nested child 1 of root",
                                        display: "deeply deeply nested child 1 of root",
                                        isSelected: false,
                                        indeterminate: false,
                                        currentId: 5,
                                        prevId: 4,
                                        child: []
                                    }
                                ]
                            }
                        ]
                    },
                    {
                        value: "nested child 1 of root",
                        display: "nested child 1 of root",
                        isSelected: false,
                        indeterminate: false,
                        currentId: 6,
                        prevId: 2,
                        child: []
                    }
                ]
            },
            {
                value: "child 2 of root",
                display: "child 2 of root",
                isSelected: false,
                indeterminate: false,
                currentId: 7,
                prevId: 1,
                child:[]
            },
            {
                value: "child 3 of root",
                display: "child 3 of root",
                isSelected: false,
                indeterminate: false,
                currentId: 8,
                prevId: 1,
                child:[]
            }
        ]
    }
];
function addParentRef(nodes, parent = null) {
  nodes.forEach((node) => {
    // Attach a reference to the parent (could be null if at root)
    node._parent = parent;
    
    // If this node has children, recurse and pass this node as the parent
    if (node.child && node.child.length > 0) {
      addParentRef(node.child, node);
    }
  });
}
addParentRef(data);

export default data;

let depObj = {};
const personObj = {
    name: "chandan",
    age: "24",
    address: {
        city: "bangaloer",
        pincode: "560037",
        lat:"123"
    }
}
function deepCopy(obj, depObj) {
    let keys = Object.keys(obj);
    for (let i = 0; i < keys.length; i++){
        let value = obj[keys[i]]
        let key = keys[i];
        if (Array.isArray(value)) {
            depObj[key] = [];
            for (let j = 0; j < value.length; j++) {
                const currValue = value[j];
                if (typeof currValue == 'object') {
                    depObj[key][j] = {};
                    deepCopy(value[j],depObj[key][j])
                } else {
                    depObj[key][j] = currValue;
                }
            }
        }
        else if (typeof value == "object") {
            depObj[key] = {};
            deepCopy(obj[key], depObj[key]);
        } else {
            depObj[key] = value;
        }
    }
    
}

const res  = deepCopy(personObj,depObj)
console.log("res", res);


// const obj = { a: 1 };
// obj.self = obj; // Circular reference