import React,{useState} from 'react'

const Checkbox = ({ item, handleCheckBoxChange = () => { } }) => {
    const [isChecked, setisChecked] = useState(item?.isSelected ? item?.isSelected : false);
    const handleCheckBoxChange1 = (e, item) => {
        // console.log("ee,", e.target.checked);
        // console.log("item,", item);
        handleCheckBoxChange(e, item)
    }
    return (
        <div className='checkBox'>
            <input type="checkbox" checked={item.isSelected} onChange={(e) => handleCheckBoxChange1(e, item)} />
            <label for="vehicle1">{item.display}</label>
        </div>
    )
}

export default Checkbox