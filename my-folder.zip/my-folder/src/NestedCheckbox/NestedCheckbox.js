import React, { useState } from 'react';
import data from './data';
import MultiCheckbox from './MultiCheckbox';
import './style.css';

const NestedCheckbox = () => {
  console.log("data==>", data);
  const [filters, setFilters] = useState(data);
    function buildNodeMap(data) {
    const nodeMap = {};

    function traverse(nodes) {
      nodes.forEach((node) => {
        nodeMap[node.currentId] = node;
        if (node.child && node.child.length) {
          traverse(node.child);
        }
      });
    }

    traverse(data);
    return nodeMap;
    }
  const nodeMap = buildNodeMap(data);
  const handleCheckBoxChange = (e, item) => {
    let tempfilters = JSON.parse(JSON.stringify(filters));
    let value = e.target.checked;
    dfsHelper(tempfilters, item, value);
    updateParent(tempfilters._parent);
    // nodeId
    // const childNode = nodeMap[nodeId];
    //  updateParentStatus(item, childNode);
    console.log("tempfilters", tempfilters);
    setFilters(tempfilters);
  };
  // data is the top-level array of root nodes
  // nodeMap will be { [currentId]: nodeObject }


  const dfsHelper = (tempfilters = [], item, value, nestedTrue = false) => {
    tempfilters?.forEach((filter) => {
      if (nestedTrue) {
        filter.isSelected = value;
      }
      if (filter.currentId == item.currentId) {
        filter.isSelected = value;
        dfsHelper(filter.child, item, value, true)
        return
      }
      dfsHelper(filter.child, item, value, nestedTrue);
    })
  }
  // check if nested value is check then check parent child value



  function updateParentStatus(nodeMap, childNode) {
  let currentNode = childNode;
  
  while (currentNode.parentId) {
    // 1. Find the parent in the nodeMap
    const parent = nodeMap[currentNode.parentId];
    if (!parent) break; // safety check

    // 2. Check parent's children
    const { child: siblings } = parent;
    if (!siblings || !siblings.length) break;

    // Are all siblings selected?
    const allChecked = siblings.every(s => s.isSelected);
    // Are all siblings unchecked or not indeterminate?
    const noneChecked = siblings.every(
      s => !s.isSelected && !s.indeterminate
    );

    if (allChecked) {
      parent.isSelected = true;
      parent.indeterminate = false;
    } else if (noneChecked) {
      parent.isSelected = false;
      parent.indeterminate = false;
    } else {
      parent.isSelected = false;
      parent.indeterminate = true;
    }

    // Move up one level
    currentNode = parent;
  }
}

  
  function updateParent(parent) {
    if (!parent) return;
    const children = parent.child;
    const allChecked = children.every((child) => child.checked);
    const allUnchecked = children.every((child) => !child.checked && !child.indeterminate);
    if (allChecked) {
      parent.checked = true;
      parent.indeterminate = false;
    } else if (allUnchecked) {
      parent.checked = false;
      parent.indeterminate = false;
    } else {
      parent.checked = false;
      parent.indeterminate = true;
    }
    updateParent(parent._parent)
  }
  return (
    <div className='nestedCheck'>
      <MultiCheckbox filters={filters} handleCheckBoxChange={handleCheckBoxChange} />
    </div>
  )
}

export default NestedCheckbox;