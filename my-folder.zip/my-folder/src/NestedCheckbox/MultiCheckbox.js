import React from 'react'
import Checkbox from './Checkbox'

const MultiCheckbox = ({ filters,handleCheckBoxChange }) => {
    return (
        <div className='nestedComments'>
            {filters?.map((filter, index) => {
                return (
                    <>
                        <Checkbox item={filter} handleCheckBoxChange={ handleCheckBoxChange} />
                        {filter?.child.length > 0 && <MultiCheckbox filters={filter.child} handleCheckBoxChange={ handleCheckBoxChange} />}
                    </>
                )
            })}

        </div>
    )
}

export default MultiCheckbox