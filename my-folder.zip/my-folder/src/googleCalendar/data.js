const mockEvents = [
    {
    id: 12,
    title: "standup meeting",
    start: "3:30",
    end: "4:00",
    color: "blue"
    },
    {
    id: 12,
    title: "group call",
    start: "8:30",
    end: "9:30",
    color: "blue"
    },
    {
    id: 13,
    title: "solution decision",
    start: "18:30",
    end: "21:30",
    color: "red"
    },
    {
    id: 13,
    title: "calendar decision",
    start: "18:30",
    end: "19:30",
    color: "green"
    },
    {
    id: 14,
    title: "solution decision",
    start: "19:00",
    end: "20:30",
    color: "red"
    },
    // {
    // id: 14,
    // title: "standup meeting",
    // start: "13:30",
    // end: "14:30",
    // color: "blue"
    // },
    // {
    // id: 15,
    // title: "standup meeting",
    // start: "13:30",
    // end: "14:30",
    // color: "blue"
    // },
    // {
    // id: 16,
    // title: "standup meeting",
    // start: "13:30",
    // end: "14:30",
    // color: "blue"
    // }
]

export default mockEvents;