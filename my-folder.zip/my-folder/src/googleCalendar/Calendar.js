import React,{useState} from 'react';
import mockEvents from './data';
import './style.css';
const HOUR_HEIGHT = 60; // px per hour
const MINUTE_HEIGHT = HOUR_HEIGHT / 60; // px per minute

function timeToMinutes(timeString) {
  const [hh, mm] = timeString.split(':').map(Number);
  return hh * 60 + mm;
}

// Helper to determine if two events overlap

function eventsOverlapTemp(e1, e2) {
  return (
    timeToMinutes(e1.start) > timeToMinutes(e2.start) &&
    timeToMinutes(e1.start) < timeToMinutes(e2.end)
  );
}

function eventsOverlap(e1, e2) {
  return (
    timeToMinutes(e1.start) < timeToMinutes(e2.end) &&
    timeToMinutes(e1.end) > timeToMinutes(e2.start)
  );
}

export default function Calendar() {
    const [events, setEvents] = useState(mockEvents);
  // Sort events by start time to help with positioning
  const sortedEvents = [...events].sort(
    (a, b) => timeToMinutes(a.start) - timeToMinutes(b.start)
  );

  // We will first figure out if there are overlaps and assign each event
  // a "column index" so that overlapping events can be displayed side-by-side.
  // This is a simplistic approach that can be improved.
  let columns = [];
    const updatedEvents = sortedEvents.map((event) => {
      // debugger
    // Check columns to find a place for this event
      console.log("event==>>", event);
    let colIndex = 0;
      for (; colIndex < columns.length; colIndex++) {
          console.log("colIndex", colIndex);
      // If it doesn't overlap with anything in this column, we can put it here
      if (!columns[colIndex].some((ev) => eventsOverlap(ev, event))) {
        columns[colIndex].push(event);
        return { ...event, column: colIndex };
      }
    }
    // Otherwise, create a new column
    columns.push([event]);
    return { ...event, column: columns.length - 1 };
    });
    
    function countOverLapEvents(event) {
        let count = 0;
        sortedEvents.forEach((currEve) => {
            if (eventsOverlapTemp(currEve, event)) {
                count++;
            }
        })
        console.log("count", count);
        return count;
    }
    console.log("updatedEvents==>>", updatedEvents);
  // For a single‐day vertical layout
  const hours = Array.from({ length: 24 }, (_, i) => i);

  return (
    <div className="calendar-container">
      {/* Left side: hour labels */}
      <div className="calendar-hours">
        {hours.map((hour) => (
          <div key={hour} className="hour-label">
            {hour}:00
          </div>
        ))}
      </div>

      {/* Right side: the time "grid" + events */}
      <div className="calendar-body">
        {/* The grid (background) */}
        <div className="time-grid">
          {hours.map((hour) => (
            <div key={hour} className="time-slot" />
          ))}
        </div>

        {/* Events absolutely positioned on top */}
        {updatedEvents.map((event) => {
          const startOffset = timeToMinutes(event.start) * MINUTE_HEIGHT;
          const duration = (timeToMinutes(event.end) - timeToMinutes(event.start)) * MINUTE_HEIGHT;
          const overLap = countOverLapEvents(event);
          console.log("overLap", overLap);
          return (
            <div
              key={event.id}
              className="calendar-event"
              style={{
                top: startOffset,
                height: duration,
                left: `${overLap * 150}px`, // 150px wide columns
                backgroundColor: event.color,
              }}
            >
              <span className="event-title">{event.title}</span>
              <span className="event-time">
                {event.start} - {event.end}
              </span>
            </div>
          );
        })}
      </div>
    </div>
  );
}
