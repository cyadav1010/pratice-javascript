
# /** 
#  user ->id, name, emailId
#  movie -> gerne, movieId, title, description, duration,getDetails() |
#  threater-> screen[],location,name, getAvailableSeats,  , addScreen 
#  screen-> screenId, show, Seat[][], availbleSeats, bookseats, releaseSeats
#  show->id, movie, starttime, endtime, isAvailable,
#  Booking->id, user, show, seats, status, confirmBooking, cancleBooking
#  Payment->id, amount, status, processPayment,
  
# **/


# 1)Understand the Requirements
# 2)Break Down the Problem
# 3)Plan the Architecture
# 4)Design the Data Flow
# 5)Optimize the Feed UI
# 6)
# 7)Focus on Performance Optimizations
# 7)Plan for Scalability
# 8)Test and Iterate
# 9) Communicate Your Design
# 10)