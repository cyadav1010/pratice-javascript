import React, { useState } from 'react'
import mockEvents from './data';
import './timeSlots.css';


const GoogleCalendar = () => {
    const HOUR_HEIGHT = 60; // px per hour
    const MINUTE_HEIGHT = HOUR_HEIGHT / 60; // px per minute
    const [events, setEvents] = useState(mockEvents);
    const timeToMinutes = (timeString) => {
        const timeParts = timeString.split(':');
        const hh = Number(timeParts[0]);
        const mm = Number(timeParts[1]);
        return hh * 60 + mm;
    }
    // const eventsOverlap = (e1, e2) => {
    //     if(timeToMinutes(e1.start))
    // }
    const timeSlots = Array.from({ length: 24 }, (_, index) => index);
    console.log("timeSlots", timeSlots);
    const getTitle = () => { };

    const sortedEvents = [...events].sort((a, b) => timeToMinutes(a.start) - timeToMinutes(b.start));
    return (

        <div className='google-calendar'>
            <div className='hour-container'>
                {timeSlots?.map((hour) => {
                    return (
                        <div key={hour} className="hourWrapper">
                            {hour}:00
                        </div>
                    )
                })}
            </div>
            <div className='calendar-bodyWrapper'>
                <div className='timeEvents-container'>
                    {timeSlots?.map((hour) => {
                        return (
                            <div key={hour} className="timeEvents">
                                {/* {hour}:00 */}
                            </div>
                        )
                    })}
                </div>
                {/* <div className='displayEvents'> */}
                {
                    events?.map((event) => {
                        const startOffset = timeToMinutes(event.start);
                        const duration = timeToMinutes(event.end) - timeToMinutes(event.start);

                        return (
                            <div style={{ top: startOffset, height: duration, backgroundColor: event.color, width: '140px',position:'absolute' }}>
                                <div> {event.title}</div>
                                <div> {event.start}-{event.end}</div>
                            </div>
                        )
                    })
                    }
                    {/* </div> */}
            </div>
        </div>
        // <div className='calendarWrapper'>
        //     {timeSlots?.map((time) => {
        //         return (
        //             <div className='timeSlots'>
        //                 <div className='displayTiming'>
        //                     {time}
        //                 </div>
        //             </div>
        //         )
        //     })}
        //     {
        //         events?.map((event) => {
        //             const startOffset = timeToMinutes(event.start) * MINUTE_HEIGHT;
        //             const duration = (timeToMinutes(event.end) - timeToMinutes(event.start)) * MINUTE_HEIGHT;
        //             return (
        //                 <div style={{ top: startOffset,height:duration,backgroundColor:event.color,width:'100%',opacity:0.7 }} className='displayEvent'>
        //                     {event.title}
        //                 </div>)
        //         })
        //     }
        // </div>
    )
}

export default GoogleCalendar

