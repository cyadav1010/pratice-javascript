import React, { useState } from "react";

const DropdownExample = () => {
    const [selectedOption, setSelectedOption] = useState(""); // State for selected value

    // Options for the dropdown
    const options = [
        { value: "apple", label: "Apple" },
        { value: "banana", label: "Banana" },
        { value: "orange", label: "Orange" },
    ];

    // Handle dropdown value change
    const handleChange = (event) => {
        setSelectedOption(event.target.value);
    };

    return (
        <div>
            <h2>Select a fruit:</h2>
            <select value={selectedOption} onChange={handleChange}>
                <option value="" disabled>
                    Choose an option
                </option>
                {options.map((option) => (
                    <option key={option.value} value={option.value}>
                        {option.label}
                    </option>
                ))}
            </select>
            <p>Selected Option: {selectedOption || "None"}</p>
        </div>
    );
};

export default DropdownExample;
