class Node {
    constructor(key, value) {
        this.key = ley;
        this.value = value;
        this.prev = null;
        this.next = null;
    }
}

// ["LRUCache", "put" , "get"
class LRUCache {
    constructor(capacity) {
        this.capacity = capacity;
        this.map = new Map();
        this.head = new Node(-1, -1);
        this.tail = new Node(-1, -1);
        this.head.next = this.tail;
        this.tail.prev = this.head;
    }

    // if key is present then remove that node and put at 
    get(key) {
        if (!this.map.has(key)) {
            return -1;
        }
        let node = this.map.get(key);
        this.remove(node);
        this.add(node);
        return node.value;
    }
    put(key, value) {
        if (this.map.has(key)) {
            this.remove(this.map.get(key));
        }
        let newNode = new Node(key, value);
        this.add(newNode);
        this.map.set(key, newNode);
        if (this.map.size > this.capacity) {
            let nodeToDelete = this.head.next;
            this.remove(nodeToDelete);
            this.map.delete(nodeToDelete.key)
        }
    }

    add(node) {
        let prevNode = this.tail.prev;
        node.next = this.tail;
        node.prev = prevNode;
        this.tail.prev = node;
        prevNode.next = node;
    }
    remove(node) {
         let preNode = node.prev;
        let nxtNode = node.next;
        preNode.next = nxtNode;
        nxtNode.prev = preNode;
    }
}