import { configureStore } from "@reduxjs/toolkit";
import { createStore } from "redux";
import todoReducer from "./reducers/todoReducer";

// const store = configureStore({
//     reducer: todoReducer,
// });

const store = createStore(todoReducer);
export default store;



// // Internally Redux does something like this:
// const newState = {
//   watchList: watchListReducer(state.watchList, action),
//   orderList: orderListReducer(state.orderList, action)
// };
