const initialState = {
  todos: [], // `todos` state initialized here
};

const todoReducer = (state = initialState, action) => {
  switch (action.type) {
    case "ADD_TODO":
      return {
        ...state,
        todos: [...state.todos, action.payload],
      };
    default:
      return state;
  }
};

export default todoReducer;


const todoReducerExample = (state = initialState, action) => {
    switch (action.type) {
        case "ADD_TODO":
            return {
                ...state, 
                todos: [...state.todos, action.payload],
            }
        default:
            return state;
    }
    // switch (key) {
    //     case value:
            
    //         break;
    
    //     default:
    //         break;
    // }
}