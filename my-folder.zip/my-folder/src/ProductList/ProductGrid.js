import React, { useEffect, useRef, useState } from 'react';

function ProductGrid({ products=[] }) {
    const [visibleProducts, setVisibleProducts] = useState([]);
    const productsRef = useRef([]);
    // const [products, setProducts] = useState([]);
    // useEffect(() => {
    //     fetch('https://dummyjson.com/products')
    //         .then(res => res.json()).then((data) => {
    //             console.log("data", data);
    //             setProducts(data?.products)
    //         })
    //         .then(console.log);
    // }, [])
    useEffect(() => {
        const observer = new IntersectionObserver(
            (entries) => {
                entries.forEach((entry) => {
                    if (entry.isIntersecting) {
                        setVisibleProducts((prevVisible) => [...prevVisible, entry.target.id]);
                    } else {
                        setVisibleProducts((prevVisible) =>
                            prevVisible.filter((id) => id !== entry.target.id)
                        );
                    }
                });
            },
            { threshold: 0.5 } // Trigger when 50% of the product is visible
        );
        console.log("productsRef.current", productsRef.current);
        productsRef.current.forEach((ref) => {
            if (ref) {
                console.log("ref", ref);
                observer.observe(ref);
            }
        })
        // const productElements = document.querySelectorAll('.product-card');
        // productElements.forEach((element) => observer.observe(element));

        // return () => {
        //     productElements.forEach((element) => observer.unobserve(element));
        // };
        return () => {
            productsRef.current.forEach((ref) => {
                if (ref) {
                    observer.unobserve(ref);
                }
            })
        }
    }, []);
    useEffect(() => {
        console.log("visibleProducts", visibleProducts);
    }, [visibleProducts]);
    return (
        <div className="product-grid">
            {products.map((product,index) => (
                <div
                    key={product.id}
                    id={product.id}
                    ref={ (ele)=>(productsRef.current[index]=ele)}
                    className="product-card"
                >
                    <img src={product.image} alt={product.category} />
                    <h3>{product.title}</h3>
                    <p>${product.price}</p>
                </div>
            ))}
            <p>Visible Products: {visibleProducts.join(', ')}</p>
        </div>
    );
}

export default ProductGrid;