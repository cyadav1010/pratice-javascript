import React, { useState, useEffect, useCallback } from "react";
import { FixedSizeList as List } from "react-window";

const PAGE_SIZE = 20; // Number of products to fetch per page

const ProductList = () => {
    const [products, setProducts] = useState([]); // Loaded products
    const [isLoading, setIsLoading] = useState(false); // API loading state
    const [hasMore, setHasMore] = useState(true); // Indicates if more products are available

    // Fetch product data from the API
    const fetchProducts = useCallback(async () => {
        if (isLoading || !hasMore) return; // Prevent duplicate fetch
        setIsLoading(true);

        try {
            const response = await fetch(
                `https://fakestoreapi.com/products?limit=${PAGE_SIZE}&skip=${products.length}`
            );
            const newProducts = await response.json();

            if (newProducts.length < PAGE_SIZE) {
                setHasMore(false); // Stop fetching when no more data
            }

            setProducts((prev) => [...prev, ...newProducts]); // Append new products
        } catch (error) {
            console.error("Error fetching products:", error);
        } finally {
            setIsLoading(false);
        }
    }, [isLoading, hasMore, products.length]);

    useEffect(() => {
        fetchProducts(); // Initial load
    }, [fetchProducts]);

    // Load more data when user scrolls near the bottom
    const handleScroll = ({ visibleStopIndex }) => {
        if (visibleStopIndex >= products.length - 1 && hasMore) {
            fetchProducts();
        }
    };

    // Product row renderer
    const Row = ({ index, style }) => {
        const product = products[index];
        return product ? (
            <div style={style} className="product-row">
                <img src={product.image} alt={product.title} width="50" height="50" />
                <span>{product.title}</span>
            </div>
        ) : (
            <div style={style}>Loading...</div> // Loading placeholder
        );
    };

    return (
        <List
            height={600} // Visible list height
            itemCount={products.length + (hasMore ? 1 : 0)} // Add placeholder for loading
            itemSize={100} // Height of each row
            width="100%"
            onItemsRendered={({ visibleStopIndex }) => handleScroll({ visibleStopIndex })}
        >
            {Row}
        </List>
    );
};

export default ProductList;
