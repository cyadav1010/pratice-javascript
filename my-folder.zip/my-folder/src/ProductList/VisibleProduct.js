import React,{useState,useEffect} from 'react'
import ProductGrid from './ProductGrid';

const VisibleProduct = () => {
    const [products, setProducts] = useState([]);
    useEffect(() => {
        fetch('https://dummyjson.com/products')
            .then(res => res.json()).then((data) => {
                console.log("data", data);
                setProducts(data?.products)
            })
            .then(console.log);
    }, [])
  return (
      <div>
          {products?.length > 0 && <ProductGrid products={products} />}
    </div>
  )
}

export default VisibleProduct