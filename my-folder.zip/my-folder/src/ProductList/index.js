import React, { useState, useEffect } from "react";
import { FixedSizeList as List } from "react-window";

const PAGE_SIZE = 20;

const ProductList = () => {
    const [products, setProducts] = useState([]);
    const [isLoading, setIsLoading] = useState(false);

    useEffect(() => {
        fetchMoreProducts();
    }, []);

    const fetchMoreProducts = () => {
        if (isLoading) return;

        setIsLoading(true);
        fetch(`https://fakestoreapi.com/products?limit=${PAGE_SIZE}`)
            .then((res) => res.json())
            .then((newProducts) => {
                setProducts((prev) => [...prev, ...newProducts]);
                setIsLoading(false);
            });
    };

    const handleScroll = ({ scrollOffset, scrollHeight, clientHeight }) => {
        if (scrollOffset + clientHeight >= scrollHeight - 10) {
            fetchMoreProducts();
        }
    };

    const Row = ({ index, style }) => (
        <div style={style}>{products[index]?.title || "Loading..."}</div>
    );

    return (
        <List
            height={600}
            itemCount={products.length + 1} // Add one to show "loading" placeholder
            itemSize={50}
            width="100%"
            onScroll={({ scrollOffset, scrollHeight, clientHeight }) =>
                handleScroll({ scrollOffset, scrollHeight, clientHeight })
            }
        >
            {Row}
        </List>
    );
};

export default ProductList;
